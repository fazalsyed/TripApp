

import UIKit

class SouthIndiaVC: UIViewController {

    @IBOutlet var img_background: UIImageView!
    var ArrNameSouth : [String]  = ["Munnar", "Goa", "Ooty", "Hampi", "Kerala Backwaters", "Pondicherry", "Coorg", "Madurai", "Kodaikanal"]
    var ArrImgSouth : [String] = ["ic_Munnar","ic_Goa","ic_Ooty","ic_Hampi","ic_Kerala","ic_Pondicherry","ic_Coorg","ic_Madurai","ic_Kodaikanal"]
    @IBOutlet var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "CellC_Destination", bundle: nil), forCellWithReuseIdentifier: "CellC_Destination")
        img_background.layer.cornerRadius = 15
        img_background.layer.borderWidth = 1
        img_background.layer.borderColor = UIColor.gray.cgColor
        
    }
}
extension SouthIndiaVC : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return ArrNameSouth.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_Destination", for: indexPath) as! CellC_Destination
        cell.lbl_Destination.text = ArrNameSouth[indexPath.row]
        cell.img_Destination.image = UIImage(named: ArrImgSouth[indexPath.row])
        cell.img_Destination.layer.cornerRadius = 8
        cell.img_Destination.layer.borderWidth = 1
        cell.img_Destination.layer.borderColor = UIColor.gray.cgColor
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SouthTripList") as? SouthTripList
        vc?.selectedindex = indexPath.row
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = collectionView.bounds.width
        return CGSize(width: size/2-6, height: size/2-6)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 2, left: 2, bottom: 0, right: 2)
    }
}

