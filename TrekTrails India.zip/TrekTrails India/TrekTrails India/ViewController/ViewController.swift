//
//  ViewController.swift
//  TrekTrails India
//
//  Created by syed fazal abbas on 04/09/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var NorthContainer: UIView!
    @IBOutlet var SouthContainer: UIView!
    @IBOutlet var EastContainer: UIView!
    @IBOutlet var WestContainer: UIView!
    @IBOutlet var CentralContainer: UIView!
    @IBOutlet var btnCentral: UIButton!
    @IBOutlet var btnWest: UIButton!
    @IBOutlet var btnEast: UIButton!
    @IBOutlet var btnSouth: UIButton!
    @IBOutlet var btnNorth: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        NorthContainer.isHidden = false
        SouthContainer.isHidden = true
        EastContainer.isHidden = true
        WestContainer.isHidden = true
        CentralContainer.isHidden = true
    }


    @IBAction func btnTappedNorth(_ sender: UIButton) {
        NorthContainer.isHidden = false
        SouthContainer.isHidden = true
        EastContainer.isHidden = true
        WestContainer.isHidden = true
        CentralContainer.isHidden = true
        btnNorth.titleLabel?.font = UIFont(name: "Academy Engraved LET", size: 25)
        [btnEast,btnWest,btnSouth,btnCentral].forEach { $0.titleLabel?.font = UIFont(name: "Academy Engraved LET", size: 20) }
    }
    
    @IBAction func btnTappedSouth(_ sender: UIButton) {
        SouthContainer.isHidden = false
        NorthContainer.isHidden = true
        EastContainer.isHidden = true
        WestContainer.isHidden = true
        CentralContainer.isHidden = true
        btnSouth.titleLabel?.font = UIFont(name: "Academy Engraved LET", size: 25)
        [btnEast,btnWest,btnNorth,btnCentral].forEach { $0.titleLabel?.font = UIFont(name: "Academy Engraved LET", size: 20) }
    }
    
    @IBAction func btnTappedEast(_ sender: UIButton) {
        EastContainer.isHidden = false
        NorthContainer.isHidden = true
        SouthContainer.isHidden = true
        WestContainer.isHidden = true
        CentralContainer.isHidden = true
        btnEast.titleLabel?.font = UIFont(name: "Academy Engraved LET", size: 25)
        [btnSouth,btnWest,btnNorth,btnCentral].forEach { $0.titleLabel?.font = UIFont(name: "Academy Engraved LET", size: 20) }
    }
    
    @IBAction func btnTappedWest(_ sender: UIButton) {
        WestContainer.isHidden = false
        NorthContainer.isHidden = true
        SouthContainer.isHidden = true
        EastContainer.isHidden = true
        CentralContainer.isHidden = true
        btnWest.titleLabel?.font = UIFont(name: "Academy Engraved LET", size: 25)
        [btnSouth,btnEast,btnNorth,btnCentral].forEach { $0.titleLabel?.font = UIFont(name: "Academy Engraved LET", size: 20) }
    }
    
    
    @IBAction func btnTappedCentral(_ sender: UIButton) {
        CentralContainer.isHidden = false
        NorthContainer.isHidden = true
        SouthContainer.isHidden = true
        EastContainer.isHidden = true
        WestContainer.isHidden = true
        btnCentral.titleLabel?.font = UIFont(name: "Academy Engraved LET", size: 25)
        [btnSouth,btnEast,btnNorth,btnWest].forEach { $0.titleLabel?.font = UIFont(name: "Academy Engraved LET", size: 20) }
    }
}
