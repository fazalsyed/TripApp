//
//  EastTripList.swift
//  TrekTrails India
//
//  Created by syed fazal abbas on 08/09/23.
//

import UIKit

class EastTripList: UIViewController {

    
    var selctedIndex : Int?
    
    //Marks Darjeeling Array Detail
    var arrDarjeelingplacename = [
        "Tiger Hill",
        "Batasia Loop",
        "Darjeeling Himalayan Railway",
        "Padmaja Naidu Himalayan Zoological Park",
        "Peace Pagoda (Japanese Temple)",
        "Rock Garden and Ganga Maya Park",
        "Observatory Hill and Mahakal Temple",
        "Darjeeling Mall Road",
        "Tea Gardens",
        "Himalayan Mountaineering Institute (HMI)"
    ]
    var imgDarjelling : [String] = ["ic_Tiger Hill","ic_Batasia_Loop","ic_Darjeeling_Railway","ic_Padmaja","ic_Peace","ic_Rock_Garden ","ic_Observatory ","ic_Darjeeling","ic_Tea_Gardens","ic_Himalayan"]
    var arrDarjeelingtripduration = [
        "1 day",
        "2-3 hours",
        "3-4 hours",
        "2-3 hours",
        "1-2 hours",
        "2-3 hours",
        "2-3 hours",
        "3-4 hours",
        "2-3 hours",
        "2-3 hours"
    ]
    var arrDarjeelingbestseaosn = [
        "Spring and Autumn",
        "Spring and Autumn",
        "Spring and Autumn",
        "Spring and Autumn",
        "Spring and Autumn",
        "Spring and Autumn",
        "Spring and Autumn",
        "Spring and Autumn",
        "Spring and Autumn",
        "Spring and Autumn"
    ]
    var arrDarjeelingpeakseason  : [String] = [
        "March to May and September to November",
        "March to May and September to November",
        "March to May and September to November",
        "March to May and September to November",
        "March to May and September to November",
        "March to May and September to November",
        "March to May and September to November",
        "March to May and September to November",
        "March to May and September to November",
        "March to May and September to November"
    ]

    var arrDarjeelingDetail : [String] = ["Tiger Hill is an iconic vantage point in Darjeeling renowned for its breathtaking sunrise views over the Himalayan mountain range, including the majestic Kanchenjunga peak. Visitors often wake up early to witness the golden hues of the sunrise painting the snow-capped peaks, creating a mesmerizing sight. It's a place of natural beauty and tranquility, where the first rays of the sun illuminate the world's third-highest mountain.","Batasia Loop is a unique engineering marvel of the Darjeeling Himalayan Railway, a UNESCO World Heritage Site. This spiral railway loop offers panoramic views of Darjeeling town and the surrounding mountains. The loop is adorned with a beautifully landscaped garden, a War Memorial, and a charming toy train station. It's a delightful stop for train enthusiasts and those seeking picturesque vistas.","The Darjeeling Himalayan Railway, affectionately known as the Toy Train, is a historic narrow-gauge railway that winds its way through the picturesque landscapes of Darjeeling. Riding the toy train is like stepping back in time, as it chugs through tea plantations, forests, and charming villages. The railway is not just a mode of transportation but an enchanting journey that showcases the region's natural beauty.","This zoological park is dedicated to preserving the endangered Himalayan wildlife, including the elusive snow leopard and the red panda. It provides a natural habitat for these species and offers visitors a chance to observe them up close. The park's well-maintained enclosures, lush surroundings, and educational exhibits make it a must-visit for nature and wildlife enthusiasts.","The Peace Pagoda, a serene Japanese temple, stands as a symbol of peace and harmony in Darjeeling. The gleaming white stupa offers stunning views of the Himalayas and the town below. Visitors can explore the temple's tranquil grounds, enjoy moments of reflection, and admire the intricate Buddhist architecture. It's a place of spirituality and serenity.","The Rock Garden and Ganga Maya Park are lush terraced gardens featuring beautiful waterfalls, rock formations, and meandering pathways. These parks offer a serene escape from the hustle and bustle of the city. Visitors can relax by the cascading water, explore the rock-cut pathways, and revel in the natural beauty of the area.","Observatory Hill is a sacred hill that houses the Mahakal Temple and offers panoramic views of Darjeeling. The temple is dedicated to Lord Shiva, and the hill is a pilgrimage site for Hindus and Buddhists alike. It's a place where spirituality meets natural beauty, making it a peaceful spot for contemplation and worship.","The Mall Road in Darjeeling is a bustling promenade lined with shops, restaurants, and colonial-era buildings. It's a hub of activity where visitors can indulge in shopping for souvenirs, savor local cuisine, and take leisurely walks. The Mall Road is the heart of Darjeeling's social life and provides a glimpse into the town's colonial history.","Darjeeling is renowned for its world-famous tea, and a visit to the tea gardens is a must. These lush plantations offer guided tours where visitors can learn about tea cultivation, processing, and tasting. The aroma of fresh tea leaves and the sprawling green landscapes create a sensory delight.","The Himalayan Mountaineering Institute is a revered institution that pays homage to Darjeeling's mountaineering legacy. Founded by Tenzing Norgay, the institute offers mountaineering courses, a museum showcasing mountaineering history, and a memorial to Sir Edmund Hillary. It's a place to learn about the region's mountaineering feats and gain insight into the challenges of conquering the world's highest peaks."]
    
    //Marks : Kolkata Array Detail
    
    var arrKolkataplacename = [
        "Victoria Memorial",
        "Howrah Bridge",
        "Indian Museum",
        "Dakshineswar Kali Temple",
        "Belur Math",
        "Kali Ghat Temple",
        "Science City",
        "Mother House",
        "Eden Gardens",
        "Park Street"
    ]
    var imgKolkata : [String] = ["ic_Victoria_Memorial","ic_Howrah_Bridge","ic_Indian_Museum","ic_Dakshineswar","ic_Belur_Math","ic_Kali","ic_Science","ic_Mother","ic_Eden","ic_Park"]
    var arrkolkatatripduration = [
        "2-3 hours",
        "1-2 hours",
        "2-3 hours",
        "1-2 hours",
        "1-2 hours",
        "1-2 hours",
        "3-4 hours",
        "1-2 hours",
        "2-3 hours",
        "3-4 hours"
    ]
    var arrkolkatabestseaosn = [
        "Winter",
        "Winter",
        "Winter",
        "Winter",
        "Winter",
        "Winter",
        "Winter",
        "Winter",
        "Winter",
        "Winter"
    ]
    var arrkolkatapeakseason = [
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March"
    ]
    var arrkolkataDetail : [String] = ["The Victoria Memorial is an iconic architectural masterpiece located in the heart of Kolkata. This grand marble structure was built in memory of Queen Victoria and is a symbol of the city's colonial heritage. The memorial houses a museum that showcases a rich collection of art, artifacts, and historical exhibits. Its lush gardens and reflective pools make it a serene oasis in the bustling city.","The Howrah Bridge, officially known as the Rabindra Setu, is an engineering marvel and an iconic landmark of Kolkata. This cantilever bridge spans the Hooghly River, connecting Howrah and Kolkata. It's not only a crucial transportation link but also a symbol of the city's identity. Illuminated at night, the bridge is a breathtaking sight.","The Indian Museum in Kolkata is one of the oldest and largest museums in India. It boasts an extensive collection of art, archaeology, anthropology, and natural history artifacts. Visitors can explore galleries dedicated to sculptures, fossils, mummies, and ancient manuscripts, providing a fascinating glimpse into India's rich heritage.","The Dakshineswar Kali Temple is a revered Hindu temple dedicated to Goddess Kali. Located on the banks of the Hooghly River, it is known for its distinctive architecture and serene ambiance. The temple complex includes 12 shrines, a large courtyard, and a sacred bathing ghat. Pilgrims and visitors come to seek blessings and immerse themselves in spiritual tranquility.","Belur Math is the headquarters of the Ramakrishna Math and Ramakrishna Mission and an important pilgrimage site. The serene campus showcases a harmonious blend of various architectural styles, reflecting the ideals of universal religion and harmony espoused by Swami Vivekananda. The main temple is dedicated to Sri Ramakrishna Paramahansa, and it's a place for reflection and spirituality.","The Kali Ghat Temple, officially known as the Kalighat Kali Temple, is one of the most revered Kali temples in Kolkata. It is believed to be one of the 51 Shakti Peethas in Hindu mythology. Devotees visit to worship the Goddess Kali and seek her blessings. The temple's unique architecture and cultural significance make it a must-visit for those interested in Hindu spirituality.","Science City is an interactive and educational science center that offers a fun and informative experience for visitors of all ages. It features a range of exhibits, interactive displays, a space theater, and a butterfly garden. Science City aims to foster curiosity and scientific thinking while providing an entertaining day out.","Mother House is the headquarters of the Missionaries of Charity, the religious congregation founded by Mother Teresa. It's a place of reverence and reflection, where visitors can pay their respects to Mother Teresa and learn about her life and humanitarian work. The simple chapel and museum offer insight into her legacy of compassion.","Eden Gardens is one of the most renowned cricket stadiums in the world. It has witnessed historic cricket matches and is a hallowed ground for cricket enthusiasts. Even if there isn't a match, the vast green expanse and scenic beauty of the gardens make it a pleasant spot for a leisurely stroll.","Park Street is a vibrant and iconic thoroughfare in Kolkata known for its restaurants, cafes, pubs, and cultural events. It's a hub of nightlife and entertainment, where people come to dine, socialize, and enjoy live music. The street is a reflection of Kolkata's cosmopolitan charm."]
    
    //Marks : Sikkim Array Detail
    
var arrSikkimPlaceName: [String] = ["Gangtok", "Tsomgo Lake", "Yumthang Valley", "Pelling", "Ravangla"]
    var imgSikkim : [String] = ["ic_Gangtok","ic_Tsomgo_Lake","ic_Yumthang ","ic_Pelling","ic_Ravangla"]
var arrSikkimTripDuration: [String] = ["2-3 days", "Half-day trip", "2-3 days", "2-3 days", "1-2 days"]
var arrSikkimBestSeason: [String] =  ["Throughout the year", "April to June & October to December", "April to June & September to November", "February to May & September to November", "February to May & September to November"]
    var arrSikkimPeakSeason: [String] = ["March to June & October to December", "April to June & October to December", "April to June & September to November", "March to May & September to November", "March to May & September to November"]
    var arrSikkimDetail : [String] = ["Gangtok, the capital city of Sikkim, is nestled in the Eastern Himalayas and offers a perfect blend of natural beauty and urban charm. Surrounded by breathtaking mountain vistas, Gangtok is known for its serene monasteries, lush greenery, and vibrant markets. You can explore the Enchey Monastery, take a ride on the Gangtok Ropeway, and stroll through MG Marg, a bustling street filled with shops and eateries. Gangtok is a gateway to several other beautiful destinations in Sikkim.","Tsomgo Lake, also known as Changu Lake, is a mesmerizing high-altitude lake located about 40 kilometers from Gangtok. This glacial lake is renowned for its stunning reflections of the surrounding mountains and its frozen beauty in the winter months. Visitors can enjoy yak rides and savor local snacks while taking in the tranquil ambiance. The lake is particularly enchanting during the spring when the rhododendrons are in bloom.","Yumthang Valley, often referred to as the Valley of Flowers, is a pristine paradise located in North Sikkim. Known for its alpine meadows, hot springs, and vibrant blooms of rhododendrons, this valley is a nature lover's dream. Yumthang is best visited in the spring when the valley comes alive with a riot of colors. It offers a serene environment for those seeking solitude and natural beauty.","Pelling is a serene hill station in West Sikkim that provides breathtaking views of the Kanchenjunga mountain range. The town is dotted with monasteries, waterfalls, and lush forests, making it an ideal destination for nature enthusiasts. Key attractions include the Pemayangtse Monastery, Rabdentse Ruins, and the Khecheopalri Lake, considered sacred by both Buddhists and Hindus. Pelling is an excellent place to unwind and soak in the serene Himalayan atmosphere.","Ravangla, a tranquil town situated in South Sikkim, is known for its scenic beauty and serene atmosphere. The town is surrounded by lush tea gardens and offers panoramic views of the Himalayan peaks. Ravangla is famous for the Buddha Park, where you can find a 130-foot tall statue of Lord Buddha. The nearby Tathagata Tsal (Buddha Park) offers a meditative environment and picturesque vistas."]
    
    //Marks : Gangtok Array Detail
var arrGangtokPlaceName: [String] = ["Rumtek Monastery", "MG Marg", "Enchey Monastery", "Do Drul Chorten", "Tashi Viewpoint"]
    var imgGangtok : [String] = ["ic_Rumtek_Monastery","ic_MG","ic_Enchey","ic_Do ","ic_Tashi_Viewpoint"]
var arrGangtokTripDuration: [String] = ["Half-day trip", "Half-day trip", "Half-day trip", "Half-day trip", "Half-day trip"]
var arrGangtokBestSeason : [String] = ["Throughout the year", "Throughout the year", "Throughout the year", "Throughout the year", "Throughout the year"]
var arrGangtokPeakSeason: [String] = ["March to June & October to December", "Throughout the year", "Throughout the year", "Throughout the year", "Throughout the year"]
    var arrGangtokDetail : [String] = ["Rumtek Monastery, also known as the Dharma Chakra Centre, is a significant Tibetan Buddhist monastery located about 24 kilometers from Gangtok. It is not only a place of worship but also an architectural marvel. The monastery houses numerous precious artifacts, religious relics, and a magnificent golden stupa. Visitors can explore the peaceful surroundings, participate in religious ceremonies, and admire the intricate Tibetan art and architecture.","MG Marg, short for Mahatma Gandhi Marg, is the vibrant heart of Gangtok. This pedestrian-only street is lined with shops, restaurants, cafes, and boutiques. It's a perfect place to stroll, shop for souvenirs, savor local and international cuisine, and soak in the lively atmosphere. MG Marg is beautifully illuminated in the evenings, making it a delightful spot for an evening walk.","Enchey Monastery is a serene and ancient Buddhist monastery located on a hilltop just a short drive from Gangtok's city center. The monastery is known for its stunning architecture, intricate woodwork, and peaceful ambiance. It is dedicated to the worship of the guardian deity of Sikkim, and visitors can witness traditional Buddhist rituals and ceremonies here. The surrounding forest adds to the monastery's tranquil charm.","Do Drul Chorten is a prominent stupa (Buddhist shrine) located in Gangtok. This sacred site is adorned with prayer wheels, colorful prayer flags, and a serene atmosphere. It's a place where both locals and visitors come to offer prayers and circumambulate the stupa. The chorten is surrounded by lush gardens and provides panoramic views of the surrounding hills.","Tashi Viewpoint offers breathtaking panoramic views of the Kanchenjunga mountain range on clear days. It's located approximately 8 kilometers from Gangtok and provides a serene escape from the city's hustle and bustle. Sunrise is the best time to visit, as you can witness the first rays of sunlight illuminate the snow-capped peaks. There's also a small café where you can enjoy a hot cup of tea while taking in the majestic scenery."]
    
    //Marks : Sundarbans Data in Arra
var arrSundarbansPlaceName: [String] = ["Sundarbans National Park", "Sajnekhali Wildlife Sanctuary", "Sundarbans Tiger Reserve", "Dobanki Watchtower", "Sundarbans Delta"]
    var imgSundarband : [String] = ["ic_Sundarbans","ic_ajnekhali","ic_Sundarbans_Tiger","ic_Dobanki","ic_Sundarbans_Delta"]
var arrSundarbansTripDuration: [String] =  ["2-3 days", "1 day", "2-3 days", "Half-day trip", "2-3 days"]
var arrSundarbansBestSeason: [String] = ["October to March", "October to March", "October to March", "October to March", "October to March"]
var arrSundarbansPeakSeason:  [String] = ["December to February", "December to February", "December to February", "December to February", "December to February"]
    var arrSundarbansDetail : [String] = ["Sundarbans National Park, located in the delta region of West Bengal, India, is one of the largest mangrove forests in the world and a UNESCO World Heritage Site. It is famous for its rich biodiversity, including the elusive Bengal tiger. Visitors can explore the dense mangrove forests, meandering waterways, and numerous islands. Boat safaris are a popular way to navigate through the park, offering a chance to spot tigers, crocodiles, various bird species, and other wildlife in their natural habitat. The park is a unique ecosystem and a must-visit for nature enthusiasts and wildlife lovers.","Sajnekhali Wildlife Sanctuary is a part of the Sundarbans Reserve Forest and serves as a popular entry point for tourists. It is home to the Sajnekhali Bird Sanctuary, where you can observe a diverse range of bird species. The sanctuary also features a watchtower offering panoramic views of the surrounding mangrove forests and waterways. Visitors can learn about the unique ecosystem of the Sundarbans at the Sajnekhali Interpretation Center.","Sundarbans Tiger Reserve is a critical area for tiger conservation. It encompasses the core tiger habitat within the Sundarbans. Visitors to this reserve have the opportunity to go on tiger tracking expeditions, although sightings are rare due to the dense mangrove cover. The reserve is not only about tigers; it's also a sanctuary for various other wildlife species, including saltwater crocodiles, estuarine dolphins, and a variety of birds.","The Dobanki Watchtower is one of the watchtowers within the Sundarbans National Park. It offers an excellent vantage point for wildlife enthusiasts to observe the diverse fauna of the Sundarbans. From the watchtower, you can spot crocodiles, various species of birds, and if you're lucky, some glimpses of the Bengal tiger. The surrounding mangrove landscape adds to the beauty and uniqueness of the experience.","The Sundarbans Delta itself is a natural wonder and a major attraction. It comprises a network of rivers, water channels, and islands formed by the confluence of the Ganges, Brahmaputra, and Meghna rivers as they flow into the Bay of Bengal. The delta is not only ecologically significant but also culturally rich, with several local communities living in harmony with the mangrove forests. Exploring the delta by boat allows you to witness the intricate waterways, lush greenery, and unique way of life of the people living here."]
    
    //Marks : Puri Array Detail
    
var arrPuriPlaceName: [String] = ["Jagannath Temple", "Puri Beach", "Konark Sun Temple", "Chilika Lake", "Raghurajpur Crafts Village"]
    var imgPuri : [String] = ["ic_Jagannath","ic_Puri-Beach","ic_Konark ","ic_Chilika","ic_Raghurajpur"]
var arrPuriTripDuration: [String] = ["Half-day trip", "Half-day trip", "Half-day trip", "Full-day trip", "Half-day trip"]
var arrPuriBestSeason: [String] = ["October to March", "October to March", "October to March", "October to March", "October to March"]
var arrPuriPeakSeason: [String] = ["November to February", "November to February", "November to February", "November to February", "November to February"]
    var arrPuriDetails : [String] = ["The Jagannath Temple is one of the most revered Hindu temples in India, located in the heart of Puri. It is dedicated to Lord Jagannath, an incarnation of Lord Vishnu, and is a significant pilgrimage site for Hindus. The temple's architecture is a marvel, featuring towering spires and intricate stone carvings. Inside, you'll find the deities of Lord Jagannath, Lord Balabhadra, and Devi Subhadra. The temple is also famous for its annual Rath Yatra, a grand chariot procession that attracts millions of devotees. Visitors can experience the spiritual and cultural richness of this iconic temple.","Puri Beach is a picturesque stretch of coastline along the Bay of Bengal. It is a popular destination for both tourists and pilgrims. The golden sands, crashing waves, and the view of the sun rising and setting over the sea make it a serene and beautiful spot. Visitors can enjoy leisurely walks along the beach, indulge in water sports, and savor local snacks from the numerous stalls. The beach is also known for its religious significance, as taking a dip in the sea here is considered purifying by Hindu devotees.","The Konark Sun Temple, a UNESCO World Heritage Site, is located about 35 kilometers from Puri. It is an architectural masterpiece dedicated to the Sun God, Surya. The temple is designed in the shape of a colossal chariot with intricately carved stone wheels and sculptures. It is a testament to the exquisite craftsmanship of ancient India. The temple complex also houses a museum showcasing artifacts and sculptures from the site. The Konark Sun Temple is a must-visit for history buffs and architecture enthusiasts.","Chilika Lake, Asia's largest brackish water lagoon, is a short drive from Puri. The lake is a haven for birdwatchers and nature lovers, as it hosts a diverse range of migratory birds and is home to the endangered Irrawaddy dolphins. Visitors can take boat rides to explore the lake's islands, watch birds, and enjoy the tranquil surroundings. The Nalabana Island within Chilika Lake is a designated wildlife sanctuary and a significant Ramsar Wetland site.","Raghurajpur is a charming crafts village located near Puri, renowned for its rich artistic heritage. The village is famous for its Pattachitra paintings (traditional cloth-based scroll paintings), palm leaf engravings, and traditional Odissi dance and music. Visitors can watch local artisans create intricate artwork, shop for unique handicrafts, and immerse themselves in the vibrant cultural traditions of the region. Raghurajpur offers a glimpse into the artistic soul of Odisha."]

    //Marks : Shilong Array Detail
var arrShilongPlaceName: [String] = ["Elephant Falls", "Shillong Peak", "Umiam Lake", "Don Bosco Museum", "Police Bazar"]
    var imgShilong : [String] = ["ic_Elephant_Falls","ic_Shillong","ic_Umiam","ic_Don ","ic_Police"]
var arrShilongTripDuration: [String] = ["1-2 hours", "2-3 hours", "Half-day trip", "2-3 hours", "Flexible"]
var arrShilongBestSeason: [String] = ["September to May", "September to May", "September to May", "Throughout the year", "Throughout the year"]
var arrShilongPeakSeason: [String] = ["March to May & September to November", "March to May & September to November", "March to May & September to November", "Throughout the year", "Throughout the year"]
    var arrShilongDetail : [String] = ["Elephant Falls, located just outside Shillong, is a magnificent natural attraction. The falls are named after a local legend involving an elephant. The cascading waterfalls flow through lush greenery and rocky terrain, creating a serene and picturesque setting. Visitors can explore the falls from different viewpoints, with a staircase leading to the bottom pool. It's a great place for nature lovers, photographers, and those seeking a peaceful escape into the natural beauty of Meghalaya.","Shillong Peak is the highest point in the Shillong area, offering panoramic views of the city and its surroundings. Visitors can reach the summit by driving or hiking, and the vista from the top is especially breathtaking during sunrise or sunset. The viewpoint provides a perfect opportunity to capture stunning photographs and appreciate the lush hills and valleys that stretch out below.","Umiam Lake, often referred to as the Lake of Shillong, is a vast and picturesque reservoir. Surrounded by emerald hills and forests, it's a popular spot for water-based activities like boating, kayaking, and water skiing. The lake's tranquility and scenic beauty make it an ideal place for a leisurely picnic or a relaxing day by the water. Sunset boat rides on the lake are particularly enchanting.","The Don Bosco Museum is a cultural and heritage museum in Shillong, showcasing the rich and diverse cultures of the northeastern states of India. The museum's architecture is distinctive, resembling a spiral and featuring seven floors. Each floor is dedicated to a particular state or theme, offering insights into their history, traditions, and art forms. It's an educational and enlightening experience for those interested in the cultural mosaic of the region.","Police Bazar is the heart of Shillong's commercial and shopping district. It's a bustling market area where you can find everything from local handicrafts and traditional attire to modern fashion and electronic gadgets. The market comes alive with vibrant street food stalls, cafes, and shops offering a wide range of products. It's not just a shopping destination but also a place to experience the local culture and cuisine of Shillong."]
    
    //Marks : kaziranaga Arrary Detail
var arrkaziranagaPlaceName: [String] = ["Kaziranga Safari", "Kaziranga National Orchid Park", "Kaziranga Biodiversity Park", "Kaziranga Elephant Safari"]
    var imgkaziranga : [String] = ["ic_Kaziranga_Safari","ic_Kaziranga","ic_Kaziranga_Biodiversity","ic_Kaziranga_Elephant"]
var arrkaziranagaTripDuration: [String] = ["Half-day to full day", "1-2 hours", "1-2 hours", "Half-day to full day"]
var arrkaziranagaBestSeason: [String] =  ["November to April", "Throughout the year", "Throughout the year", "November to April"]
var arrkaziranagaPeakSeason: [String] = ["December to February", "Throughout the year", "Throughout the year", "December to February"]
    var arrkazirangaDetail : [String] = ["The Kaziranga Safari is the primary attraction within Kaziranga National Park and offers visitors a chance to explore the park's diverse wildlife and pristine landscapes. You can choose from various safari options, including jeep safaris and elephant safaris. The park is renowned for its population of the Indian one-horned rhinoceros, and you'll have the opportunity to spot these magnificent creatures in their natural habitat. Additionally, Kaziranga is home to tigers, elephants, deer, water buffalo, and a wide variety of bird species. The safaris allow you to experience the park's breathtaking beauty and biodiversity while being guided by knowledgeable naturalists.","The Kaziranga National Orchid Park is a paradise for orchid enthusiasts and nature lovers. It is home to a stunning collection of over 600 species of orchids, many of which are native to the region. The park's well-maintained pathways lead you through a lush green environment where you can admire the vibrant colors and unique shapes of these exquisite flowers. The park also features a small museum and a conservation center dedicated to the preservation of orchid species. It's a tranquil and educational experience for botany enthusiasts.","The Kaziranga Biodiversity Park is dedicated to conserving and showcasing the rich biodiversity of the Kaziranga region. It provides visitors with an opportunity to learn about the various plant and animal species that call the park home. The park has informative signage, walking trails, and viewing points where you can observe wildlife and enjoy the serene surroundings. It's an excellent place for nature enthusiasts and those interested in understanding the importance of conservation efforts in Kaziranga.","The Kaziranga Elephant Safari offers a unique and up-close wildlife viewing experience. Riding atop trained elephants, you can venture deep into the park's grasslands and dense forests, providing a different perspective on the park's wildlife. The slow and silent movement of elephants allows for close encounters with rhinoceros, tigers, and other animals without disturbing them. It's a memorable and eco-friendly way to explore the wilderness of Kaziranga National Park."]
    
    //Mark : BodhGaya
var arrBodhGayaPlaceName: [String] =  ["Mahabodhi Temple", "Bodhi Tree", "Great Buddha Statue", "Dungeshwari Cave Temples", "Sujata Stupa"]
    var imgBodhgaya : [String] = ["ic_Mahabodhi","ic_Bodhi","ic_Great","ic_Dungeshwari","ic_Sujata"]
var arrBodhGayaTripDuration: [String] =  ["2-3 hours", "1-2 hours", "1-2 hours", "2-3 hours", "1-2 hours"]
var arrBodhGayaBestSeason:  [String] = ["October to March", "October to March", "October to March", "October to March", "October to March"]
var arrBodhGayaPeakSeason:  [String] = ["October to March", "October to March", "October to March", "October to March", "October to March"]
    var arrBodhGayaDeatils : [String] = ["The Mahabodhi Temple is one of the most sacred Buddhist pilgrimage sites in the world. It marks the spot where Lord Buddha is believed to have attained enlightenment under the Bodhi Tree. The temple's architecture is a magnificent blend of Indian and Buddhist styles, with a towering spire and intricate carvings. Inside the temple, you can find a gilded statue of Lord Buddha in a meditative posture. The temple complex also includes the Vajrasana (Diamond Throne), which is believed to be the actual spot where Buddha sat during his enlightenment. The serene and spiritual atmosphere of the Mahabodhi Temple makes it a place of deep reverence and reflection for Buddhists and visitors alike.","The Bodhi Tree is a sacred fig tree located within the Mahabodhi Temple complex. It is considered one of the oldest and most significant trees in the world. According to tradition, this tree is a direct descendant of the original tree under which Buddha attained enlightenment. Pilgrims and visitors come to meditate and offer prayers beneath the tree, which provides a tranquil and shaded environment. The presence of the Bodhi Tree adds to the spiritual aura of the entire complex.","The Great Buddha Statue, also known as the 80-foot Buddha, is a massive bronze statue of Lord Buddha in a seated meditative pose. It is located near the Mahabodhi Temple and is a symbol of peace and enlightenment. The statue is surrounded by lush gardens and provides a peaceful space for meditation and reflection. Its imposing presence and serene expression make it a captivating sight and a place for spiritual contemplation.","The Dungeshwari Cave Temples, also known as the Mahakala Caves, are located a short distance from Bodh Gaya. These caves are of great significance in Buddhism as they are believed to be the place where Siddhartha Gautama, who later became Lord Buddha, practiced extreme austerity before his enlightenment. The caves are simple yet spiritually charged, and visitors can explore the small chambers where Siddhartha engaged in deep meditation and self-discipline. The peaceful and remote location adds to the contemplative atmosphere.","The Sujata Stupa is located in the village of Sujata, near Bodh Gaya. It commemorates a significant event in the life of Buddha. It is believed that a young girl named Sujata offered a bowl of rice pudding (kheer) to an emaciated Siddhartha Gautama before his enlightenment. The stupa stands at the site of this generous act and serves as a symbol of kindness and compassion. Pilgrims and visitors often come to pay their respects and reflect on the importance of generosity in the Buddhist tradition."]

    @IBOutlet var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "CellC_OriginDetail", bundle: nil), forCellWithReuseIdentifier: "CellC_OriginDetail")
    }
}
extension EastTripList : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let selctedIndex = selctedIndex{
            switch selctedIndex{
            case 0:
                return arrDarjeelingplacename.count
            case 1:
                return arrKolkataplacename.count
            case 2:
                return arrSikkimPlaceName.count
            case 3:
                return arrGangtokPlaceName.count
            case 4:
                return arrSundarbansDetail.count
            case 5:
                return arrPuriPlaceName.count
            case 6:
                return arrShilongPlaceName.count
            case 7:
                return arrkaziranagaPlaceName.count
            case 8:
                return arrBodhGayaPlaceName.count
            default:
                return 0
            }
        }
        return 0 
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let selctedIndex = selctedIndex{
            switch selctedIndex{
            case 0:
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lbl_stateName.text = ""
                cell.lbl_OriginTittle.text = arrDarjeelingplacename[indexPath.row]
                cell.lblPeakSeason.text  = arrDarjeelingpeakseason[indexPath.row]
                cell.lblTripDuration.text = arrDarjeelingtripduration[indexPath.row]
                cell.lbl_bestTimeToVisit.text = arrDarjeelingbestseaosn[indexPath.row]
                cell.img_Origin.image = UIImage(named: imgDarjelling[indexPath.row])
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 1:
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lbl_stateName.text = ""
                cell.lbl_OriginTittle.text = arrKolkataplacename[indexPath.row]
                cell.lblPeakSeason.text  = arrkolkatapeakseason[indexPath.row]
                cell.lblTripDuration.text = arrkolkatatripduration[indexPath.row]
                cell.lbl_bestTimeToVisit.text = arrkolkatabestseaosn[indexPath.row]
                cell.img_Origin.image = UIImage(named: imgKolkata[indexPath.row])
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 2:
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lbl_stateName.text = ""
                cell.lbl_OriginTittle.text = arrSikkimPlaceName[indexPath.row]
                cell.lblPeakSeason.text  = arrSikkimPeakSeason[indexPath.row]
                cell.lblTripDuration.text = arrSikkimTripDuration[indexPath.row]
                cell.lbl_bestTimeToVisit.text = arrSikkimBestSeason[indexPath.row]
                cell.img_Origin.image = UIImage(named: imgSikkim[indexPath.row])
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 3:
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lbl_stateName.text = ""
                cell.lbl_OriginTittle.text = arrGangtokPlaceName[indexPath.row]
                cell.lblPeakSeason.text  = arrGangtokPeakSeason[indexPath.row]
                cell.lblTripDuration.text = arrGangtokTripDuration[indexPath.row]
                cell.lbl_bestTimeToVisit.text = arrGangtokBestSeason[indexPath.row]
                cell.img_Origin.image = UIImage(named: imgGangtok[indexPath.row])
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 4:
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lbl_stateName.text = ""
                cell.lbl_OriginTittle.text = arrSundarbansPlaceName[indexPath.row]
                cell.lblPeakSeason.text  = arrSundarbansPeakSeason[indexPath.row]
                cell.lblTripDuration.text = arrSundarbansTripDuration[indexPath.row]
                cell.lbl_bestTimeToVisit.text = arrSundarbansBestSeason[indexPath.row]
                cell.img_Origin.image = UIImage(named: imgSundarband[indexPath.row])
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 5:
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lbl_stateName.text = ""
                cell.lbl_OriginTittle.text = arrPuriPlaceName[indexPath.row]
                cell.lblPeakSeason.text  = arrPuriPeakSeason[indexPath.row]
                cell.lblTripDuration.text = arrPuriTripDuration[indexPath.row]
                cell.lbl_bestTimeToVisit.text = arrPuriBestSeason[indexPath.row]
                cell.img_Origin.image = UIImage(named: imgPuri[indexPath.row])
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 6:
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lbl_stateName.text = ""
                cell.lbl_OriginTittle.text = arrShilongPlaceName[indexPath.row]
                cell.lblPeakSeason.text  = arrShilongPeakSeason[indexPath.row]
                cell.lblTripDuration.text = arrShilongTripDuration[indexPath.row]
                cell.lbl_bestTimeToVisit.text = arrShilongBestSeason[indexPath.row]
                cell.img_Origin.image = UIImage(named: imgShilong[indexPath.row])
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 7:
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lbl_stateName.text = ""
                cell.lbl_OriginTittle.text = arrkaziranagaPlaceName[indexPath.row]
                cell.lblPeakSeason.text  = arrkaziranagaPeakSeason[indexPath.row]
                cell.lblTripDuration.text = arrkaziranagaTripDuration[indexPath.row]
                cell.lbl_bestTimeToVisit.text = arrkaziranagaBestSeason[indexPath.row]
                cell.img_Origin.image = UIImage(named: imgkaziranga[indexPath.row])
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 8:
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lbl_stateName.text = ""
                cell.lbl_OriginTittle.text = arrBodhGayaPlaceName[indexPath.row]
                cell.lblPeakSeason.text  = arrBodhGayaPeakSeason[indexPath.row]
                cell.lblTripDuration.text = arrBodhGayaTripDuration[indexPath.row]
                cell.lbl_bestTimeToVisit.text = arrBodhGayaBestSeason[indexPath.row]
                cell.img_Origin.image = UIImage(named: imgBodhgaya[indexPath.row])
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            default:
                return UICollectionViewCell()
            }
        }
       return UICollectionViewCell()
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AboutDetailVC") as? AboutDetailVC
        if let selectedindex = selctedIndex{
            switch selectedindex{
            case 0 :
                vc?.EastIndia = arrDarjeelingDetail[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            case 1:
                vc?.EastIndia = arrkolkataDetail[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            case 2:
                vc?.EastIndia = arrSikkimDetail[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            case 3:
                vc?.EastIndia = arrGangtokDetail[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            case 4:
                vc?.EastIndia = arrSundarbansDetail[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            case 5:
                vc?.EastIndia = arrPuriDetails[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            case 6:
                vc?.EastIndia = arrShilongDetail[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            case 7:
                vc?.EastIndia = arrkazirangaDetail[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            case 8:
                vc?.EastIndia = arrBodhGayaDeatils[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            default : break
            }
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        if let selectedindex = selctedIndex{
            switch selectedindex{
            case 0:
                return 0
            case 1:
                return 0
            case 2:
                return 0
            case 3:
                return 0
            case 4:
                return 0
            case 5:
                return 0
            case 6 :
                return 0
            case 7:
                return 0
            case 8:
                return 0
                default :
                return 0.0
            }
        }
        return 0.0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        if let selectedindex = selctedIndex{
            switch selectedindex{
            case 0:
                return 0
            case 1:
                return 0
            case 2:
                return 0
            case 3:
                return 0
            case 4:
                return 0
            case 5:
                return 0
            case 6 :
                return 0
            case 7:
                return 0
            case 8:
                return 0
                default :
                return 0.0
            }
        }
        return 0.0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = collectionView.bounds.width
        if let selectedindex = selctedIndex{
            switch selectedindex{
            case 0:
                return CGSize(width: size/1, height: size/1)
             
            case 1:
                return CGSize(width: size/1, height: size/1)
            case 2:
                return CGSize(width: size/1, height: size/1)
            case 3:
                return CGSize(width: size/1, height: size/1)
            case 4:
                return CGSize(width: size/1, height: size/1)
            case 5:
                return CGSize(width: size/1, height: size/1)
            case 6 :
                return CGSize(width: size/1, height: size/1)
            case 7:
                return CGSize(width: size/1, height: size/1)
            case 8:
                return CGSize(width: size/1, height: size/1)
                default :
                return CGSize.zero
            }
        }
        return CGSize.zero
    }
}
