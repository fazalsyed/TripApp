//
//  UttrakhandVC.swift
//  TrekTrails India
//
//  Created by syed fazal abbas on 04/09/23.
//

import UIKit

class UttrakhandVC: UIViewController {

    
    var selectedIndex : Int?
    //MArk : Uttrakhan Array
    var ArrOriginTittle : [String] = ["Haridwar","Nainital","Rishikesh"," Jim Corbett National Park","Mussoorie"," Badrinath","Almora","Auli","Gangotri","Yamunotri","Valley Of Flowers","Dehradun","Dhanaulti"]
    var ArrImgNorth : [String] = ["ic_haridwar","ic_Nainital","ic_rishikesh","ic_jimcorbet","ic_mussorie","ic_badrinath","ic_almora","ic_Auli","ic_gangotri","ic_Yamunotri","ic_valleyOfFlower","ic_Dehradun","ic_Dhanauti"]
    var ArrIdealTrip : [String] = ["1-2 Hours","2 Full Days","1-2 Days","1 Full Days","2 Full Days","1-2 Days","2 Full Days","3 Full Days","1-2 Days","1-2 Hours","2 Full Days","3-4 Days","1-2 Days","2 Days"]
    var ArrBestSeason: [String] = ["October to April","March to May & December to February","September to November & March to May","October to April","April to June & October to November","May to October","April to June & October to December","May to October","April to June & November to March","May to October","May to October","April to June & November to January","October to June","November to January & March to May"]
    var PeakSeason : [String] = ["November & May to June","December to January & May to June","October & April to June","October to April","December to January & May to June","December to January & May to June","May to June & September to October"," December to January & May to June","May to June & September to October","December to February","May to June & September to October","May to June & September to October","July & September","December to January & May to June"]
    var ArrOriginDetail : [String] = ["Situated on the banks of the River Ganges, Haridwar, literally translated as Gateway to God, is one of the seven holiest places for Hindus. It is the place where the river Ganga descends to the plains. It serves as a gateway to the Char Dham destinations of Uttarakhand which are Badrinath, Kedarnath, Gangotri, and Yamunotri. Haridwar is also one of the well known places to visit near Delhi.The history of Haridwar dates back to the period of King Vikramaditya, around the 2nd century BC. Haridwar is referred to as Mayapuri, Gangadwar, and Mokshadwar in the ancient Hindu texts and epics. The holy city of Haridwar is considered as old as Varanasi and according to legend; gods left their footprints in Haridwar. According to the Samudra Manthan, Haridwar along with Ujjain, Nashik, and Prayag (Allahabad) is one of the four sites where drops of Amrit (nectar) fell while it was being carried by Garuda.Har-ki-Pauri is one of the most important places to visit in Haridwar where thousands of people take a dip in the holy waters of the Ganges. It is believed that Prince Bhagirath served self-punishment here to rescue the souls of his ancestors who had died due to the curse of Kapil Muni. His prayers were answered and Ganga started flowing from the locks of Lord Shiva and reviving the sons of King Sagara.Chandi Devi Temple, Mansa Devi Temple at Bilwa Parvat, Vaishno Devi Temple, Bharat Mata Temple, Maya Devi Temple, Bhimgoda, Shanti Kunj, Sapt Sarovar, Triveni Ghat, Kanva Rishi Ashram, Chila Wildlife Sanctuary are the must-visit places as part of Haridwar tour packages. Haridwar is also a fast-growing industrial city as well. The city houses Bharat Heavy Electricals India Ltd and also has the first technical institute of India, the University of Roorkee, which is now known by the name of IIT Roorkee.Haridwar is one of the venues for the famous Kumbh Mela which takes place once every 12 years. Maha Kumbh Mela will be held in Haridwar in 2022. The Ardh Mela is held every six years. Baisakhi, Kanwar Mela, Somwati Amavasya, and Kartik Purnima are the other important festivals celebrated in Haridwar.Jolly Grant Airport at Dehradun is the nearest airport, which is about 38 km from Haridwar. Haridwar Railway Station is well connected by train with Delhi, Dehradun, Rishikesh, Puri, Indore, Trivandrum, Ujjain, Madurai, Okha, Saharanpur, Mumbai, Allahabad, Gorakhpur, Varanasi, Amritsar, Howrah, and Kathgodam. Haridwar can also be reached by State-run buses that connect to nearby cities as well as New Delhi.While the town experiences a moderate climate all through the year, the best time to visit Haridwar is between October and March when the weather is pleasant and suitable for sightseeing. If you wish to partake in the festivals of Haridwar then summer is the best season to visit. Ramanavami, Kanwar Mela, and the Kumbh Mela are all celebrated in summer when the day is hot but the evenings are cool. If your only wish is to go sightseeing, then winter is a good time when the sun isn't harsh. Better to avoid visiting Haridwar during the monsoon season as there are landslides and blocked roads due to rains.","At a distance of 66 km from Ramnagar, 278 km from Dehradun, and 294 km from Delhi, Nainital is a beautiful hill station in Uttarakhand. Situated at the Kumaon foothills of Himalayas, it is one of the most popular tourist places to visit in India and among the best places to experience Uttarakhand Tourism.Nainital is famous for its scenic mountain views and is commonly known as the Lake District of India. Situated at an altitude of 1938 m, Nainital derives its name from Naini Lake, among the must include places in your Nainital tour packages. The highest point is Naina Peak or China Peak, with an elevation of 2,615 m. Nainital is surrounded by mountains on three sides and the town is spread around the beautiful Naini lake.Nainital was founded by a European businessman Percy Barron in 1841 and later it became summer retreat for the British who spent summers in these hills to escape the extreme hot weather of the plains. The British government built several schools and colleges in the region. This place is named after Naina Devi Temple, which is dedicated to Shakti, a form of Parvati. Nainital is one of the popular places to visit near Delhi.Nainital is a famous tourist destination of India, attracting large number of domestic and foreign tourists every year. Some of the important places to visit in Nainital are Naina Peak, Nainital Lake, Naina Devi Temple, Mall, Raj Bhavan, High Altitude Zoo, Bhimtal and Sattal. Naini Lake has facilities for boating and yachting. Facilities for horse riding, skating, golf, and rock climbing are also available for visitors. Nainital is also famous for its various schools and research facilities. The Observatory or The Aryabhatta Research Institute of Observational Sciences (ARIES) is the center for astronomical studies and optical tracking of artificial satellites.Pantnagar Airport (68 km) is the nearest airport to Nainital which has direct flights from Delhi. Kathgodam Railway Station is the nearest railway station, which is 24 km from Nainital. It is well connected with Moradabad, Delhi, Lucknow, Jammu Tawi, Kanpur, Dehradun, Jaisalmer and Howrah. Nainital is well connected by road with Delhi, Haldwani, Dehradun, and Rampur. Regular buses can fly from Kathgodam to Nainital.The best time to visit Nainital is from March to May & December to February. The hill station receives snowfall during the winter months from December to February, which receives the maximum number of tourists.","At a distance of 26 km from Haridwar, 42 km from Dehradun, 74 km from Mussoorie, 201 km from Chandigarh, and 233 km from Delhi, Rishikesh is a holy city on the banks of the River Ganges in Uttarakhand. Located at the foothills of the Himalayas, it is one of the top places of pilgrimage in India, and among the must-include places in Uttarakhand tour packages.Rishikesh is the gateway to the upper Garhwal region and the starting point for the Char Dham pilgrimage (Gangotri, Yamunotri, Badrinath and Kedarnath). Rishikesh is situated at an altitude of 356 m and consists of three distinct areas known as Rishikesh, Swargashram, and Muni Ki Reti. Rishikesh has been a part of the legendary Kedarkhand (the present-day Garhwal). As per the Skanda Purana, Lord Vishnu appeared here to Raibhya Rishi as Hrishikesh, which means the God of Senses.Rishesh is one of the the best places to visit near Delhi. The city attracts a huge number of tourists and pilgrims from all parts of the country to offer their prayers at this holy site. Rishikesh has several famous ashrams and temples. Triveni Ghat, Neel Kanth Mahadev Temple, Swarganiwas Temple, and Bharat Mandir are the important places to visit in Rishikesh.Rishikesh is now famous as the Yoga Capital of the World. Every year during the February month one-week-long International Yoga Festival is hosted here. One can also try several activities like mountain biking, bungee jumping, and white water rafting as part of Rishikesh tour packages. It is also the base for several trekking trails in Uttarakhand state. Rishikesh can also be visited along with Mussoorie packages.Jolly Grant Airport at Dehradun is the nearest airport, which is about 16 km from Haridwar. It is well connected by flight with Delhi. Rishikesh Railway Station is well connected by train with Delhi, Haridwar, Bandikudi, and Mata Vaishno Devi Katra. Rishikesh can also be reached by bus from Dehradun, Haridwar, and New Delhi.","The Jim Corbett National Park is a part of the largest Corbett Tiger Reserve; the Project Tiger lies in the Nainital district of Uttarakhand. The Majestic landscape of Corbett is well-known for its tiger richness. Established in the year 1936 as Hailey National Park, Corbett has the glory of being India’s oldest and most prestigious National Park. It is also being honoured as the place where Project Tiger was first launched in the year 1973. This Unique tiger territory is best known as the father who gave birth to Project Tiger in India to safeguard the most endangered species and the Royal wild animal of India called Tigers.","At a distance of 33 km from Dehradun, 187 km from Ambala, 197 km from Chandigarh, 278 km from Delhi, 263 km from Shimla and 310 km from Nainital, Mussoorie is a popular hill station in Dehradun district of Uttarakhand state. This is one of the most popular hill stations in Uttarakhand and also one of the best tourist places near Delhi. Mussoorie is one of the well known tourist destination not to miss in your honeymoon trip.Kempty Falls, Camel's Back Road and Dhanaulti are among the must include places in your Mussoorie tour packages. Mussoorie is situated atop a horseshoe crest on the mountains of Garhwal at an average altitude of 1880 m. Mussoorie offers commanding views of the underlying Doon Valley and the magnificent Himalayas. The highest in the region is Lal Tibba in Landour, with a height of over 2,275 m. Mussoorie is called the gateway to the Yamunotri and Gangotri, two sacred destinations known to be the origin of rivers Ganga and Yamuna respectively.Mussoorie gets its name from the Mansoor plant that grows in abundance in this region. It was founded in 1820 by Captain Young from the British army. The British officials visited it as a getaway from the heat during summer. During the 1959 Tibetan Rebellion, the Central Tibetan Administration of 14th Dalai Lama was first established in Mussoorie before being moved to its present location in Dharamsala, Himachal Pradesh. The first Tibetan school was established in Mussoorie in 1960.The lush green hills, the varied flora and fauna and the majestic view of the Himalayas attract thousands of tourists both domestic and international to Mussoorie each year. Mussoorie has several interesting tourist places like Kempty Falls, Gun Hill, Camel's Back Road, Jharipani Falls, Mall Road, Childer's Lodge, Bhatta Falls, Dhanaulti, and Kanatal. Mussoorie also offers some adventure and shopping opportunities. Tourists can enjoy horse riding or a leisurely walk across Camel's Back Road and a ropeway ride to the top of Gun Hills.Mussoorie has also developed into an important center of education and business. It is also famous for the Lal Bahadur Shastri National Academy of Administration where officers are trained for the Indian Administrative Service and the Indian Police Service. Mussoorie has several European schools, which started during the colonial period. Some of the oldest and best boarding schools in the country are located here.Jolly Grant Airport at Dehradun is the nearest airport, which is about 58 km from Mussoorie. It is well connected by flight with Delhi. The nearest railhead is at Dehradun, 34 km from Mussoorie. It has trains from Delhi, Okha, Indore, Trivandrum, Ujjain, Madurai, Saharanpur, Mumbai, Allahabad, Gorakhpur, Varanasi, Amritsar, Howrah and Kathgodam. Mussoorie has two bus stations, Library Bus Stand (inter-state buses) and Picture Palace Bus Station (buses to nearby places). It has buses from Delhi, Dehradun, Haridwar, Shimla and Saharanpur.Mussoorie has pleasant climate throughout the year. During spring, the town looks beautiful with blossoming flowers all around and the trees looking lush and green. The best season to visit Mussoorie is between April to June and again from September to November.","At a distance of 293 km from Rishikesh, 335 km from Dehradun and 523 km from Delhi, Badrinath is an ancient holy town in Chamoli district of Uttarakhand. It lies at an altitude of 3133 m in the Garhwal Himalayan ranges along the banks of River Alaknanda near India - Tibet border. It is one of the most famous centers of pilgrimage in India and also one of the most popular Uttarakhand places to visit as part of Char Dham.Badrinath is the most important of the four sites of famous Char Dham pilgrimage; the other three being Puri, Dwarka and Rameshwaram. It is also visited as part of Chota Char Dham Pilgrimage along with Kedarnath, Yamunotri and Gangotri in Himalayan region of Uttarakhand. Surrounded by Nar and Narayana mountain ranges and the Nilkantha peak, Badrinath has great mythical significance. This holy town is mentioned as Badari or Badarikashram in many ancient texts and scriptures. According to the epic Mahabharata, Badrinath is the site where Nara and Narayana, the dual forms of Vishnu, did meditation. It is also believed that the Pandavas passed through Badrinath on their way to heaven. Legend has it that Sage Vyasa authored Mahabharata at a cave in Mana, which is about 4 km from Badrinath.Badrinath is famous for its Badrinath Temple that houses Lord Badrinarayan, an incarnation of Lord Vishnu. The present temple is believed to have been established by saint-philosopher Adi Shankaracharya in the 8th century. Adi Shankara discovered a Saligram idol of Lord Badrinarayan in the river bed of Alaknanda. He installed this idol in a cave nearby Tapt Kund. It was later shifted to the present temple by the King of Garhwal in the 16th century.Badrinath is also famous for Panch Badri temples, which are Yog Dhyan Badri, Bhavishtya Badri, Adi Badri and Vriddha Badri, along with Badrinath temple. Some of the other attraction of Badrinath includes Tapt Kund, Narad Kund, Brahma Kapal, Sheshanetra, Charan Paduka, Neelkanth and Mana Village. Devprayag, Rudraprayag, Karnaprayag, Nandaprayag, Vishnuprayag and Pandukeswar are among the other pilgrimage sites on the route to Badarinath. Badrinath tourism also offers activities like trekking and mountaineering in the Garhwal mountain ranges.The nearest airport to Badrinath is the Jolly Grant airport of Dehradun, which is 300 km away. Rishikesh railway station is the nearest railhead to Badrinath, which is situated at a distance of 293 km. Badrinath can be reached via NH-58 which connects it to Delhi and other major cities of India. Buses from Delhi, Haridwar, Kotdwar, Dehradun and Rishikesh are available throughout the year.There are many hotels and ashrams available at Badrinath. It is preferable to stay in hotels that provide easy access to the temple and the main parts of the town. Tourists need to book the hotel in advance. Kedar-Badri Utsav, Janmashtami, Mata Murti Ka Mela, etc. are some of the main festivals celebrated here.The best time to visit Badrinath is from May to June and again from September to October. The monsoon months must be avoided as the region is prone to landslides. Tourists are advised not to visit during winters as the region receives heavy snowfall and harsh cold conditions. The Badrinath temple is closed from November to April.","At a distance of 64 km from Nainital, 50 km from Ranikhet, 357 km from Dehradun, and 364 km from Delhi, Almora, a scenic hill station in the Almora district is a famous hill resorts in Uttarakhand. It lies at an altitude of 1,651 m, amidst the southern part of the Kumaon Hills. It is a one of the popular hill stations near Delhi and also of one of the top Tourist places in Uttarakhand.Almora is located on a 5 km long horse shoe shaped ridge, the eastern portion of which is called the Talifat and the western one is known as Selifat. The Kosi and Suyal rivers run alongside the town adding to the beauty of the place. Almora is considered the cultural heart of the Kumaon region of Uttarakhand. The town got its name from kilmora, a short plant found in nearby region, which was used for washing the utensils of Katarmal Temple. The people bringing kilmora were called Kilmori and later Almori and the place came to be known as Almora. Almora is one of the top attractions you must include in Nainital packages.Almora was founded in 1568 by Kalyan Chand during the rule of the Chand dynasty. Prior to that the region was under the control of Katyuri King Bhaichaldeo and he has donated part of this land to a Gujrati Brahmin Sri Chand Tiwari. In the days of the Chand Kings it was called Rajapur and was also mentioned over a number of ancient copper plates. Later it was occupied by British forces.Almora is famous for its alluring beauty, panoramic view of the Himalayas and rich cultural heritage. Kasar Devi, Katarmal, Banari Devi, Chitai, Jageshwar, Binsar Mahadev, Govind Vallabh Pant Public Museum, Nanda Devi Temple, Almora Fort and Bright End Corner are important attractions in Almora. It also serves as the starting point for many treks like Mornaula, Mukteshwar, Binsar, and Ranikhet among others.Almora is known for its indigenous handicrafts, local cuisine and its rich culture and tradition. The traditional Panchmarchi Shawls in soft wool, decorative candles, drift wood statues and copperware are popular. Almora has been an important location for shooting Bollywood movies because of its exquisite landscape.Almora town has a several accommodation options from budget to mid-range hotels and also has a few resorts. During September, hotels are usually crowded as tourists throng the town to attend the Nanda Devi fair and so it is advisable to make your travel plans in advance.Pantnagar Airport is the nearest airport, which is about 119 km from Almora. It has direct flights from Delhi. The nearest railway station is Kathgodam, approximately 82 km from Almora. It is connected by train with Delhi, Agra, Lucknow, Jaipur, Patna, Kolkata and Mumbai. Almora is well connected by road with Nainital, Ranikhet, Kathgodam, Delhi and Haldwani.The best time to visit Almora is during the summer and during the autumn months of September & October.","At a distance of 224 km from Rishikesh, 264 km from Dehradun and 439 km from Delhi, Kedarnath is a town and a famous center of pilgrimage in Uttarakhand situated in Rudraprayag district.Kedarnath is a popular pilgrimage destination for Hindus and is one of the four major Places to visit in Uttarakhand known as Chota Char Dham pilgrimage that also includes Badrinath, Gangotri and Yamunotri. It lies at an altitude of 3584 m near Chorabari Glacier, the head of river Mandakini. It is the most remote of the four Char Dham sites and is flanked by breathtaking snow-clad peaks.Kedarnath is named after King Kedar. According to a mythology, King Kedar ruled Kedarnath during the Satya Yuga. It is believed that the temple existed even during the time of Mahabharata. It is the place where Lord Shiva absolved Pandavas from the sin of killing their own cousins Kauravas in the battle of Kurukshetra. The famous Kedarnath temple is one of the twelve Jyotirlingas and is thronged by thousands of tourists each year. Other than Kedarnath temple, Bhairavnath temple, Chorabari Tal, Shankaracharya Samadhi and Hans Kund are the some other religious places near Kedarnath.Kedarnath temple is a major tourist attraction and pilgrims book their hotels way in advance. Rooms in budget hotels and dharamshalas are available under Rs 500 and provide comfortable accommodation with basic amenities. The state-run guest houses are also available.The nearest airport to Kedarnath is the Jolly Grant airport of Dehradun, which is just 239 km away. It is well connected by flight with Delhi. Rishikesh railway station is the nearest railhead to Kedarnath, which is situated at a distance of 224 km. It is well connected by train with Delhi, Haridwar, Bandikudi and Mata Vaishni Devi Katra. Gaurikund is the nearest road point, which is 14 km from Kedarnath and is well connected by motorable roads with Rishikesh, Srinagar, Haridwar and Dehradun. The Helicopter service is also available from various places in Uttarakhand to reach Kedarnath. A helicopter can be hired from Dehradun, Gauchar, Agastyamuni, Phata or Sitapur.Kedarnath can be reached by 14 km steep climb from Gaurikund to the temple of Kedarnath and can be done on foot or on ponies. Ponies or horses are available on rent from Gaurikund. After the flash floods of 2013 which greatly affected the Kedarnath region, the route has been modified. The 14 km trek is now of 21 km which starts from Sonprayag. A general health check-up is done to ensure the safety of the tourists before allowing them to go further after registration. From here a trek of 7 km takes place up to Bhim Bali, while the next halt is at Linchauli at another 7 km. The last halt is the Kedarnath temple after a trek of another 7 km. The original route from Gaurikund runs through Rambara (7 km) - Linchauli (4 km) - Kedarnath (3 km).The extreme weather condition of Kedarnath prompts the temple to be open only for 6 months from the end of April to the beginning of November. The town receives heavy snowfall during the winter months which makes it uninhabitable. The residents of Kedarnath shift to villages lying at lower altitudes during the winter months while Lord Kedarnath's Palki is transferred to Ukhimath.","At a distance of 16 km from Joshimath, 56 km from Badrinath, 262 km from Rishikesh, 304 km from Dehradun and 495 km from Delhi, Auli is a cute hill station in Chamoli district of Uttarakhand. It is one of the best ski resorts in India and one of the top Uttarakhand tourism destinations for adventure sports. Known for its snow-cladded surroundings, Auli is one of the best places preferred by many Indians during their honeymoon tour.Auli, also known as Auli Bugyal which means meadow in Garhwali, is located at an average altitude of 2800 m in the Garhwal Himalayas. Earlier, Auli was a prominent trade centre and the trails of Auli were frequently traversed by the semi-nomadic Bhotiya tribes who maintained barter trading with Tibet for centuries. According to legend, the revered Guru Adi Shankaracharya visited Auli during 8th century AD. He built a math at Joshimath, which still is intact and is known by the name Shankaracharya Tapastali.Auli is also a beautiful ski destination, but less known compared to Shimla, Gulmarg and Manali. It was only in the recent time, after the creation of new state Uttarakhand, Auli was marketed as a tourist destination. Today, Auli is known for its snow covered slopes and panoramic views of the surroundings. The slopes of Auli were the training ground for the Indian Paramilitary Forces and Indo-Tibetan Border Police Force.Gurso Bugyal, Chattrakund, Kwani Bugyal, Hot Spring Point, Narsimha Mandir, Sankaracharya Tapastali of Joshimath, Nandaprayag, Rudraprayag and Pandukeshwar, Badrinath Mandir are the important tourist places in and around Auli. Excursions to Hemkund and Valley of Flowers are also popular among the travellers visiting Auli. Auli also offers majestic views of Mount Nanda Devi, Nanga Parbat, Dungagiri, Beethartoli, Nikanth Hathi Parbat and Ghori Parbat. It also boasts the Asia's longest cable car located at Gondola (4 km long).Skiing in Auli attracts large number of tourists. Auli has been the venue of Skiing Festivals since 1986. Today it also hosts National Championships, organized by Winter Games Federation of India, in the months of February and March. The Garhwal Mandal Vikas Nigam (GMVN) provides skiing courses for beginners and professionals at Auli, which are held for 7 to 14 days from December to March. Trekking is the most popular activity in summer and it provides a wonderful opportunity to explore the Garhwal Himalayas.Jolly Grant Airport is the nearest airport, which is about 278 km from Auli. Rishikesh railway station is situated at 262 km, serves as the nearest railway station to Auli. Joshimath is the nearest bus station to Auli which is accessible by bus service from Rishikesh, Dehradun, Nainital, Ukhimath, Chamoli, etc.Auli has limited accommodation facilities. The GMVN Skiing and Tourist Resort is a convenient place to stay as it has all the necessary facilities. Tourists also have an option of staying in tents at the Joshimath Char Dham Camp.The best time to visit Auli is from November to March for Skiing and April to June for trekking.","At a distance of 98 km from Uttarkashi, 242 km from Dehradun, 264 km from Rishikesh, 288 km from Haridwar and 483 km from Delhi, Gangotri is a popular pilgrimage town in Uttarkashi district of Uttarakhand. It is situated at an altitude of 3100 m in the Garhwal Himalayan Range on the banks of the holy Bhagirathi River. It is one of the best pilgrimage sites in India and also one of the most popular Places to visit in Uttarakhand.Gangotri, the origin of the River Ganges, is one of the four sites in the Chota Char Dham pilgrimage circuit along with Badrinath, Kedarnath and Yamunotri. River Ganges originates at Gaumukh in Gangotri Glacier, which is located about 19 km away from Gangotri town. As per legends, Goddess Ganges took the form of a river in order to absolve the sins of King Bhagiratha's ancestors, after his severe penance. Lord Shiva received River Ganges in his thick hair locks, to reduce the impact of her fierce flow.Gangotri is famous for its ancient temples and religious significance. The present Ganga Temple at Gangotri was built by a Gorkha General Amar Singh Thapa in the early 18th century. It is one of the most important temples of River Ganga. The river is called Bhagirathi at the source and acquires the name Ganga from Devprayag onwards where it meets the Alaknanda. Near the temple is located a sacred stone where King Bhagiratha is said to have worshipped Lord Shiva. Jalamagna Shivalinga, Bhavishya Badri Temple, Bhairavnath Temple and Gaumukh are the other religious attractions in Gangotri.Gangotri is a popular destination for pilgrims and adventure tourists. Activities such as river rafting, camping, trekking and skiing on Garhwal Himalayas are very popular among adventure enthusiasts. Gangotri town is the starting point of the Gaumukh, Tapovan, Nandanvan, Vasuki Tal and Gangotri-Kedartal trekking. Dayara Bugyal is the popular skiing destination near Gangotri.The nearest airport is Jolly Grant in Dehradun, which is about 277 km from Gangotri. Dehradun is the nearest railheads at a distance of 242 km. The best option to reach Gangotri is by road from Rishikesh, Haridwar or Dehradun.Gangotri has several government-managed dharamshalas are plenty and provide good accommodation. Most of the hotels in Gangotri offer decent facilities for a pleasant stay but it is advisable to book accommodation in advance.Gangotri temple is opened from May and gets closed on the occasion of Diwali festival in Oct / Nov. Gangotri temple remains closed during winters as the region is prone to heavy snowfall. The idol is shifted to Mukhyamath Temple in Mukhba village, 20 km downstream.","At a distance of 46 km from Uttarkashi, 134 km from Gangotri, 138 km from Mussoorie, 176 km from Dehradun, 209 km from Rishikesh, 224 km from Haridwar and 415 km from Delhi, Yamunotri is one of the four sites of Chota Char Dham pilgrimage situated in Uttarkashi district of Uttarakhand. It is one of the best sacred pilgrimage sites in India and also one of the most wellknown Places to visit in Uttarakhand.Yamunotri is the source of River Yamuna and is regarded as the seat of Goddess Yamuna. This is the western most shrine in the Garhwal Himalayas, situated at an altitude of 3293 m atop Bandarpunch parvat. Geologically, River Yamuna originates from the Champasar Glacier, which is located below Bandarpunch Mountain at an altitude of 4421 m. Champasar Glacier is about 1 km upstream from the riverbed near Yamunotri Temple but in order to reach the glacier one has to trek for 10 km from the temple. Yamunotri Temple can be reached by 5 km trek from Janki Chatti which is the nearest road point.According to the ancient legend, Yamunotri is also believed to be the residence of sage Asit, who used to bath in the Ganges and Yamuna each day. Unable to go to Gangotri during his old age, a stream of the Ganges appeared opposite Yamunotri for him. According to mythology, Goddess Yamuna is the daughter of Lord Surya (Sun God) and Devi Sandhya and is the sister of Lord Yama. Pilgrims believe that performing holy ablutions in Yamuna offers a painless death in old age.The chief attraction at Yamunotri is the temple devoted to the Goddess Yamuna. It is surrounded by mountains on all sides. The temple was first built by Maharani Gularia of Jaipur in the early 19th century. The temple was damaged in the earth quakes of 1923 and 1982. But it was subsequently rebuilt by Maharaja Pratap Shah of Tehri Garhwal, who was the ruler of this region. Janki Chatti, Kharsali, Saptarishi Kund, Barkot and Hanuman Chatti are the other attractions in Yamunotri. Yamunotri also has famous trekking routes, such as Hanuman Chatti - Yamunotri route, Dodi Tal, Phul Chatti route and Janki Chatti.Jolly Grant Airport is the nearest Airport to Yamunotri situated at a distance of 193 km. The nearest railway stations to Yamunotri is Dehradun (176 km). Yamunotri is does not have direct road access and the trek commences from Janki Chatti (5 km). Janki Chatti is well connected by motorable roads with Uttarkashi, Rishikesh, Barkot and Dehradun. Visitors can avail ponies or small palanquins for trek up to the Yamunotri temple from Janki Chatti.Numerous dharamshalas and hotels are available in Yamunotri. Dharamshalas are the best options to stay here which provides comfortable stay with best services. Some of the hotels in this town are Himalayan Guest House, Hotel Kalindi, Chauhan Tourist Lodge and Chauhan Annaxe. Making prior booking for hotels in peak season is recommended.The temple opens every year on the auspicious day of the Akshaya Tritiya, which generally falls during the last week of April, or early May. The temple always closes on the sacred day of Diwali in October / November. Kharsali is the winter home to the idol of goddess Yamuna. The best time to visit Yamunotri is from May to June and September to October.","At a distance of 16 km from Govind Ghat, 34 km from Joshimath, 41 km from Badrinath, 277 km from Rishikesh, 300 km from Haridwar, 318 km from Dehradun, and 518 km from Delhi, Valley of Flowers National Park is one of the most popular tourist destinations in India located in Western Himalayas in Chamoli district of Uttarakhand. It is perched at an altitude of 3600 m and is known for its meadows of endemic alpine flowers and the variety of flora. Valley of Flowers is one of the best national parks in India and also among the best Tourist places in Uttarakhand for trekking enthuasists.Stretching over a vast expanse of 87.50 sq. km, the park is about 5 km long and 2 km wide. The gentle landscape of the Valley of Flowers complements the rugged mountain of Nanda Devi National Park to the east. Together, they encompass a unique transition zone between the mountain ranges of the Zanskar and Great Himalayas. Valley of Flowers and Nanda Devi National Park, together, constitute the Nanda Devi Biosphere Reserve.The Valley of Flowers was declared a National Park in 1982 and was included in the list of UNESCO World Heritage Sites in 2004. Initially known as Bhyundar Valley, the Park was discovered and renamed in 1931 by British mountaineer Frank Smith. The highest point of the park is Gauri Parbat, at an elevation of 6719 m.The Valley of Flowers is also believed to be the place from where Hanuman brought the magical herb to resuscitate Lakshman in the Hindu epic Ramayana. The legend still holds value as many people continue to believe that Sanjeevani, the magical herb, continues to grow in the park. There are other legends associated with the park. Locals believe it is the playground of fairies and that they descend to the valley in absence of humans. At present, no settlements and grazing is allowed in the national park.The Park is known for its scenic beauty comprising alpine shrubs and different colorful flowers, milky white streams, snow-clad peaks and pristine air. More than 650 species of flowers including Brahma Kamal, Blue Poppy and Cobra Lily can be found in the Park. This richly diverse area is also home to rare and endangered animals, including the Asiatic black bear, snow leopard, musk deer, brown bear, red fox, and blue sheep. Birds found in the park include Himalayan monal pheasant and other high altitude birds.Valley of Flowers can be reached only on foot from Govind Ghat, on the Rishikesh - Badrinath Highway. Ghangaria, a scenic hamlet situated 13 km from Govind Ghat is the base station and last human habitation center on the way to Valley of Flowers (and also Hemkund Sahib). The 13 km trek from Govind Ghat to Ghangaria runs along a well maintained path, which is the base for visiting Valley of Flowers and Hemkund. This path can be covered either by walk or by pony. In addition there are a few hotels and a camp ground with tents and mattresses. Recently, an Indian airline company has started a helicopter service between Govind Ghat and Ghangaria. Visitors take night halt at Ghangaria and continue the trek to Valley of Flowers on next day.The last 3 km trek from Ghangaria to Valley of Flowers entails a steep climb. The visitors to Valley of Flowers need to get a permit from Forest Department at Ghangaria and the permit is valid for three days and visiting and trekking is allowed only during day time. As visitors are not allowed to stay inside the National park, accommodation can be obtained at Ghangaria to explore the park on multiple days. The Valley of Flowers is open throughout the day from 6 AM to 6 PM. The last entry into the park is at 3 PM.The Valley is accessible from last week of May after the snow melts. It is closed between November to April because of snow bound paths and glaciers. Best time to visit is between late July and early September, when the valley is fully covered with beautiful flowers.Jolly Grant Airport at Dehradun is the nearest airport to Valley of Flowers at a distance of 300 km, while Rishikesh is the nearest Railway Station at a distance of 277 km. Govind Ghat (16 km) is the nearest bus station 16 km away from the Valley. All the buses plying towards Badrinath stop here. Joshimath (18 km from Govind Ghat) has better bus connectivity with major towns in Uttarakhand from where several private vehicles are available to Govind Ghat.Entry Fee: Rs.150 per Indian (valid for 3 days) + Rs. 50 for each additional day, Rs.600 per Foreigner (for 3 days) + Rs. 250 for each additional day, and Rs.500 for Video Cam.","At a distance of 33 km from Mussoorie, 157 km from Chandigarh, 231 km from Delhi, 144 km from Ambala, 225 km from Shimla and 278 km from Nainital, Dehradun is the capital city of Uttarakhand and also the headquarters of Dehradun district. Dehradun is located in Doon Valley in the foothills of Himalayas nestled between two of India's mightiest rivers - the Ganges on the east and the Yamuna on the west. It is one of the wellknown destinations to experience the Tourism in Uttarakhand and also one of the popular tourist places near Delhi.The history of Dehradun city is linked to the stories of Ramayana and Mahabharata. It is believed that after the battle with Ravana, Lord Rama and his brother Laxmana visited this site. Dronacharya, the legendary Royal guru to the Kauravas and Pandavas, is believed to have been born and resided in this region. Ancient temples and ruins have been found in the nearby areas, which are almost 2000 years old. Dehradun is among the must include place in your Mussoorie tour packages.The city is famous for its picturesque landscape and pleasant weather. Dehradun is the gateway to the famous hill stations of Mussoorie, Nainital and the pilgrimage spots of Haridwar and Rishikesh. Some of the other attractions of the region are Tapkeshwar Temple, Santala Devi Temple, Tapovan, Rajaji National Park, Malsi Deer Park and several others. The city is also very famous for its Basmati rice.Dehradun hosts some important festivals of the region like Jhanda Fair, Tapkeshwar Fair, Laxman Sidh Fair, Bissu Fair, Mahasu Devta Fair, and the Shaheed Veer Kesari Chandra Fair. The city also boasts of some of India's finest schools like the Doon School for girls, Welham School for boys and institutions like the Forest Research Institute, the Indian Military Academy. Dehradun is also a haven for adventure enthusiasts. Various activities like trekking, paragliding, skiing and water sports can be experienced in Dehradun.Jolly Grant Airport at Dehradun is the nearest airport, which is about 28 km from the city center. It is well connected by flight with Delhi. Dehradun, India has a major railway station which has direct trains from Delhi, Okha, Indore, Trivandrum, Ujjain, Madurai, Saharanpur, Mumbai, Allahabad, Gorakhpur, Varanasi, Amritsar, Howrah and Kathgodam. Dehradun can also be reached by State run buses that connect to nearby cities in the region as well as New Delhi. There are regular bus services from Dehradun to MussoorieDehradun has a pleasant climate and it can be visited throughout the year. There would be occasional snowfall in the month of January.Park Timings: 6 AM to 6 PM","At a distance of 29 km from Mussoorie, 30 km from Chamba, 60 km from Dehradun, 89 km from Rishikesh, 112 km from Haridwar, 141 km from Srinagar, 224 km from Chandigarh, 258 km from Patiala, 283 km from Shimla, and 309 km from Delhi, Dhanaulti is a picturesque hill station situated in the Tehri Garhwal district of Uttarakhand. Lies on Mussoorie - Chamba Road, it is one of the popular weekend getaways from Delhi and among the best offbeat destinations to visit in Uttarakhand.Situated at an altitude of 2286 m, Dhanaulti is known for its quiet environment and tranquility. Sitting on the edge of Tehri Garhwal District, Dhanaulti shares its west-side border with Dehradun. The long wooded slopes, relaxed outdoors, cool crossing breeze, warm and hospitable inhabitants, lovely weather, and fabulous view of snow-capped mountains, makes Dhanaulti an enticing hideaway for tourists. It is still untouched and becoming an alternative to the crowded Mussoorie and Dehradun.As per the history, Dhanaulti was a princely state in the Tehri Garhwal region before India's Independence. It was reigned by King Sudarshan Shah from 1815 to 1949 with Tehri as his capital. People from this region actively participated in the freedom struggle and were part of the Quit India Movement. The people also revolted against the rule of the king of Tehri Riyasat. After the revolt, they were successful in getting independence from the Maharaja, and later, the district was merged with the state of Uttar Pradesh in India. After the bifurcation of Uttar Pradesh in the year 2000, the district of Tehri Garhwal became a part of the new state of Uttarakhand.Away from the city hustle-bustle, devoid of fancy hotels and modern cafe-style eateries, Dhanaulti is the place for those who seek a weekend of privacy in the hills. Eco Park is the main attraction of Dhanaulti. There are two Eco-parks, Amber and Dhara about 200 m apart. There is a facility for visitors to plant a sapling in the memory of their beloved, which is called as memory sapling plantation in Eco Park. Besides, Surkhanda Devi Temple, Camp Thangdhar, Potato Farm, Dhanaulti Adventure Park, Dashavatar Temple, Deogarh Fort, Kanatal Adventure Camp, and Tehri Dam are some of the top places to visit in Dhanaulti as part of Uttarakhand Tour Packages.Also, Dhanaulti is the base point for numerous treks into the snow-capped Himalayas like Surkanda Devi, Chandrabadni, and Kunjapuri. Camp Thangdhar in Thangdhar village at a distance of 14 km from Dhanaulti is an adventure camp for those interested in mountain adventure.Jolly Grant Airport, Dehradun is the nearest airport which is about 87 km from Dhanaulti. It has well-connected flights from all the major cities in India. About 60 km Dhanualti, Dehradun Railway Station is the nearest railhead that has well-connected trains from New Delhi, Ujjaini, Madurai, Varanasi, Amritsar, Kochuveli. From here, one can hire a bus or taxi to reach Dhanaulti. Dhanaulti is well connected by a road which is having both AC and Non-AC buses that conveniently operate from the major destinations like Rishikesh, Roorkee, Haridwar, Mussoorie, Nainital, and Dehradun as well.Being a small hideaway, Dhanaulti has very limited accommodation options. There are few deluxe hotels, and budget hotels along with a couple of guest houses for tourists who want to stay and explore nearby places. Apart from this, one also has the option of staying in Mussoorie and Kanatal, both of which are situated quite close to Dhanaulti that has many hotels in varied budgets.The best time to visit Dhanualti is winter for sure when this tiny hill station is completely covered in the thick blanket of snow providing varied opportunities to dwell into several adventure activities and camping. For the ones, who are not fond of winters can visit this quaint hill town in summer. during summer, Dhanaulti boasts blooming of rhododendrons, lush deodar and oak trees enveloped in the tranquilizing charm. So, the best months to visit Dhanaulti is from October to June."]
    //Mark for Rajasthan
    var ArrRajasthanPlaces: [String] = ["Jaipur", "Udaipur", "Jodhpur", "Jaisalmer", "Pushkar", "Ranthambore", "Bikaner", "Ajmer", "Chittorgarh", "Mount Abu"]
    var imgRajasthan : [String] = ["ic_Jaipur","ic_Udaipur","ic_Jodhpur","ic_Jaisalmer","ic_Pushkar","ic_Ranthambore","ic_Bikaner","ic_Ajmer","ic_Chittorgarh","ic_Mount_Abu"]
    var ArrRajasthanPlaceDetails: [String] = [
        "Jaipur, the capital of Rajasthan, is a city steeped in history and culture. Known as the Pink City due to its distinctive pink sandstone buildings, Jaipur is a vibrant blend of tradition and modernity. The city is home to iconic landmarks such as the Hawa Mahal, a palace with intricate latticework, and the majestic Amer Fort, which offers panoramic views of the city. Jaipur is also famous for its bustling bazaars, where you can shop for textiles, jewelry, and handicrafts. The City Palace, a royal residence turned museum, showcases the opulent lifestyle of the Rajput kings. Jaipur is a must-visit destination for those seeking a glimpse of Rajasthan's regal heritage.","Udaipur, often referred to as the City of Lakes, is a picturesque gem in Rajasthan. Nestled amid the Aravalli hills, the city boasts several serene lakes, with Lake Pichola being the most famous. Udaipur's crowning jewel is the City Palace, a sprawling complex that offers breathtaking views of the lake and houses a museum displaying royal artifacts. The Lake Palace, seemingly floating on Lake Pichola, is an architectural marvel that has been converted into a luxurious hotel. Udaipur's narrow alleys are lined with colorful shops, art galleries, and rooftop restaurants, creating a romantic and enchanting atmosphere. The city's rich history and stunning architecture make it a favored destination for weddings and romantic getaways.","Jodhpur, known as the Blue City for its azure-painted houses in the old quarter, is a city that exudes charm and history. Dominating the skyline is Mehrangarh Fort, a colossal fortress perched on a rocky hill. Inside the fort, visitors can explore well-preserved palaces with intricate architecture and a museum showcasing royal artifacts. The Jaswant Thada, a marble cenotaph, stands as a serene memorial to the former rulers of Jodhpur. Stroll through the bustling streets of the old city, where vendors sell textiles, spices, and handicrafts. The Clock Tower and Sardar Market are popular landmarks in this vibrant city. Jodhpur's rich cultural heritage and warm hospitality make it a captivating destination.","Jaisalmer, often referred to as the Golden City, is a desert oasis known for its stunning sand dunes and golden-hued architecture. At the heart of the city stands the majestic Jaisalmer Fort, a UNESCO World Heritage Site, characterized by its intricate carvings and imposing walls. Inside the fort, visitors can explore palaces, Jain temples, and havelis adorned with exquisite designs. Beyond the fort, the Thar Desert beckons, offering camel safaris that allow travelers to experience the stark beauty of the sand dunes and witness captivating sunsets. The city's narrow lanes are","Pushkar, a sacred town nestled around a serene lake, is a place of spiritual significance and cultural richness. The Brahma Temple, dedicated to Lord Brahma, the creator of the universe, is one of the few in the world. The Pushkar Lake, surrounded by ghats, attracts pilgrims who come to take a holy dip. Pushkar is also famous for its annual camel fair, where traders and tourists converge for a vibrant spectacle of colors, traditions, and livestock trading. The town's relaxed vibe, spiritual aura, and lively markets make it a unique destination in Rajasthan.","Ranthambore is a wildlife enthusiast's paradise, home to the majestic Bengal tiger. The Ranthambore National Park, set against the backdrop of the historic Ranthambore Fort, offers thrilling jungle safaris. Visitors can spot a variety of wildlife, including leopards, deer, and crocodiles, while exploring the ruins of the ancient fort. Ranthambore is a harmonious blend of nature and history, providing a unique and exhilarating experience for those seeking encounters with India's incredible wildlife.","Bikaner is a city steeped in history and renowned for its exquisite architecture and delectable cuisine. The Junagarh Fort, a formidable structure, showcases stunning palaces, courtyards, and temples. Bikaner is also famous for its spicy snacks, especially the world-famous bhujia The city's old bazaars offer a glimpse into its rich heritage, with handicrafts, jewelry, and textiles that reflect the craftsmanship of the region. Bikaner's blend of history and gastronomy makes it a unique destination in Rajasthan.","Ajmer, a city of spiritual significance, is known for the Ajmer Sharif Dargah, a Sufi shrine dedicated to Khwaja Moinuddin Chishti. Pilgrims from various faiths visit this revered site seeking blessings and spiritual solace. The city also boasts serene lakes like Ana Sagar Lake, where one can enjoy leisurely boat rides and peaceful moments. Ajmer's tranquil ambiance and cultural richness offer a unique experience for those exploring Rajasthan's spiritual heritage.","Chittorgarh is a city steeped in history, dominated by the grandeur of the Chittorgarh Fort, one of the largest forts in India and a UNESCO World Heritage Site. This fort is a testament to the valor and sacrifice of Rajput warriors. Exploring its massive walls, palaces, and temples transports visitors to a bygone era. Chittorgarh's historical significance and architectural marvels make it a must-visit destination for history enthusiasts.","Mount Abu is a refreshing retreat in the heart of Rajasthan, offering respite from the desert heat. As Rajasthan's only hill station, it boasts a cool and pleasant climate year-round. Nakki Lake, surrounded by lush greenery, is a serene spot for boating. The Dilwara Jain Temples, with their intricate marble carvings, are architectural wonders. Mount Abu offers scenic viewpoints like Sunset Point and Guru Shikhar, the highest peak in the Aravalli Range. This hill station provides a peaceful and scenic escape, making it a unique destination in Rajasthan."]
    
    var ArrBestSeasonRajasthan : [String] = [
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to June",
        "October to March",
        "October to March",
        "October to March",
        "April to June"
    ]
    var ArrPeakSeasonRajasthan: [String] = [
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to June ",
        "October to March",
        "October to March",
        "October to March",
        "April to June "
    ]
    var ArrTripDurationsRajasthan: [String] = [
        "2-3 days",
        "2-4 days",
        "2-3 days",
        "2-3 days",
        "1-2 days ",
        "2-3 days",
        "1-2 days",
        "1 day",
        "1-2 days",
        "2-3 days"
    ]
 //Mark Himachal Pardesh :
    var HimachalPlacesNames: [String] = [
        "Shimla",
        "Manali",
        "Dharamshala",
        "Dalhousie",
        "Kullu",
        "Kasol",
        "Solan",
        "Spiti Valley",
        "Chamba",
        "Kinnaur"
    ]
    var ImgHimachal : [String] = ["ic_Shimla","ic_Manali","ic_Dharamshala","ic_Dalhousie","ic_Kullu","ic_Kasol","ic_Solan","ic_Spiti Valley","ic_Chamba","ic_Kinnaur"]
    var HimachalPlaceDescriptions: [String] = [
        "Shimla, the capital of Himachal Pradesh, is a timeless hill station nestled in the Himalayas. Its colonial-era architecture, including the Viceregal Lodge, evokes a sense of British Raj charm. The Ridge and Mall Road are bustling with life, offering a delightful shopping and dining experience. Nature enthusiasts can explore the lush forests surrounding Shimla or embark on scenic treks to places like Jakhu Temple. The city's pleasant weather makes it an ideal escape during the scorching summers. Shimla's blend of history, culture, and natural beauty continues to enchant visitors.","Manali, cradled in the Kullu Valley, is a paradise for adventure seekers and nature lovers. Surrounded by towering snow-capped peaks, it offers an array of outdoor activities, from trekking in the Solang Valley to skiing in the winter months. The Hadimba Temple, an ancient wooden shrine, and the bustling Old Manali market are cultural highlights. Manali's scenic beauty, with lush meadows, apple orchards, and the Beas River, captivates visitors year-round.","Dharamshala, a place of spiritual significance, is home to the Tibetan government-in-exile and the residence of the Dalai Lama. Lower Dharamshala features bustling markets and the charming St. John's Church, while upper Dharamshala (McLeod Ganj) offers a serene escape. Here, you can explore Tibetan culture, visit the Namgyal Monastery, and embark on treks in the nearby Dhauladhar Range. Dharamshala's peaceful ambiance and panoramic mountain views make it a unique destination in Himachal Pradesh.","Dalhousie is a quiet and serene hill station that exudes colonial-era charm. The town is dotted with well-preserved Victorian and Scottish architecture, including St. John's Church and St. Francis Church. Dalhousie offers breathtaking views of the Pir Panjal Range and is an excellent place for nature walks. The nearby Khajjiar, often referred to as the Mini Switzerland of India, is a must-visit for its lush meadows and pristine landscapes.","Kullu, known as the Valley of Gods, is a picturesque region blessed with fertile valleys, glistening rivers, and towering mountains. It's famous for its apple orchards and the vibrant Dussehra festival. Kullu Valley offers adventure activities like river rafting and paragliding, making it a hub for thrill-seekers. The region's scenic beauty and rich culture draw travelers seeking both adventure and tranquility.","Kasol, a serene village along the Parvati River, has emerged as a haven for backpackers and nature enthusiasts. It's known for its pristine natural beauty, with trekking trails leading to destinations like Kheerganga and Tosh. The village offers a range of cafes serving delicious food and a laid-back atmosphere that's perfect for relaxation and contemplation.","Solan, often referred to as the Mushroom City of India is a peaceful town surrounded by lush greenery. It's known for its horticultural activities and is home to the revered Shoolini Devi Temple. Solan's pleasant climate and idyllic landscapes make it a rejuvenating destination for those seeking a break from the hustle and bustle of city life.","Spiti Valley, a high-altitude desert nestled in the Himalayas, is a remote and pristine destination. Its stark and breathtaking landscapes include dramatic cliffs, deep gorges, and high mountain passes. Visitors can embark on challenging treks, explore ancient monasteries like Key Monastery, and witness the unique culture of the Spiti region. The isolation and raw beauty of Spiti Valley offer a truly transformative experience for adventure enthusiasts.","Chamba, situated on the banks of the Ravi River, is a town rich in history and culture. The town is known for its temples, including the Lakshmi Narayan Temple, which showcases exquisite architectural craftsmanship. The Bhuri Singh Museum provides insights into the region's art and history. Chamba's tranquil atmosphere and historic significance make it a captivating destination for travelers interested in Himachal Pradesh's cultural heritage.","Kinnaur, a remote district in Himachal Pradesh, is renowned for its dramatic landscapes and apple orchards. The region offers trekking trails that lead to hidden villages, stunning vistas of snow-capped peaks, and the opportunity to explore the unique Kinnauri culture. Places like Kalpa and Sangla Valley provide a serene escape from the hustle of city life, making Kinnaur a destination for those seeking tranquility amidst nature's splendor."
    ]
    var HimachalBestTimeToVisit: [String] = [
        "March to June and September to November",
        "October to June",
        "March to June and September to November",
        "March to June and September to November",
        "March to June and September to November",
        "March to June and September to November",
        "March to June and September to November",
        "June to September",
        "March to June and September to November",
        "March to June and September to November"
    ]
    var HimachalPeakTimeToVisit: [String] = [
        "May to June and December to January",
        "May to June and December to January",
        "May to June and December to January",
        "May to June and December to January",
        "May to June and December to January",
        "May to June and December to January",
        "May to June and December to January",
        "July to August (for accessible roads)",
        "May to June and December to January",
        "May to June and December to January"
    ]

    var HimachalTripDurations: [String] = [
        "2-3 days",
        "3-5 days",
        "2-4 days",
        "2-3 days",
        "2-3 days",
        "2-4 days",
        "1-2 days",
        "7-10 days",
        "2-3 days",
        "3-5 days"
    ]
    //Jammu & Kashmir
    var JammuKashmirPlacesNames: [String] = [
        "Srinagar",
        "Gulmarg",
        "Pahalgam",
        "Leh",
        "Kupwara",
        "Jammu",
        "Sonmarg",
        "Vaishno Devi",
        "Doda",
        "Kathua"
    ]
    var imgJammu : [String] = ["ic_Srinagar","ic_Gulmarg","ic_Pahalgam","ic_Leh","ic_Kupwara","ic_Jammu","ic_Sonmarg","ic_Vaishno_Devi","ic_Doda","ic_Kathua"]
    var JammuKashmirPlaceDescriptions: [String] = [
        "Srinagar, often referred to as the Venice of the East, is the summer capital of Jammu and Kashmir. This picturesque city is situated in the heart of the Kashmir Valley and is renowned for its breathtaking natural beauty and rich cultural heritage. The jewel of Srinagar is the serene Dal Lake, where traditional houseboats and shikaras glide on its shimmering waters. Surrounding the lake are the Mughal Gardens, including Shalimar Bagh and Nishat Bagh, with their terraced lawns, cascading fountains, and vibrant flowerbeds.The old city of Srinagar is a labyrinth of narrow lanes and bustling bazaars. The Jama Masjid, an architectural marvel, stands as a testament to the city's historical significance. Srinagar also serves as a gateway to explore the picturesque valleys of Kashmir, making it an ideal starting point for adventures in the region.","Gulmarg, often referred to as the Meadow of Flowers, is a pristine hill station nestled in the Pir Panjal range. It is a paradise for nature lovers and adventure enthusiasts. During the summer, the town is adorned with vibrant wildflowers, lush green meadows, and dense forests. Gulmarg boasts the world's highest golf course, offering stunning views of the surrounding mountains.When winter blankets the region in snow, Gulmarg transforms into a winter wonderland. It is a magnet for skiers, snowboarders, and snow enthusiasts from around the world. The Gulmarg Gondola, one of the highest cable cars globally, whisks visitors to mountain peaks with panoramic views of the Himalayas.","Pahalgam, a serene valley town, is a gateway to the majestic Amarnath Yatra pilgrimage and a haven for nature enthusiasts. Nestled beside the Lidder River, Pahalgam offers lush green meadows, crystal-clear streams, and a tranquil ambiance. The Aru Valley and Betaab Valley, located nearby, present stunning landscapes for hiking and relaxation.As the starting point for the Amarnath Yatra, Pahalgam sees thousands of pilgrims annually. The annual pilgrimage to the sacred Amarnath Cave is a significant religious event in the region. The town provides a peaceful retreat for those seeking solace amidst nature's beauty.","Leh, the largest town in Ladakh, is a high-altitude desert destination that offers breathtaking landscapes, ancient monasteries, and a unique cultural experience. The Leh Palace, perched atop a hill, offers commanding views of the town and the surrounding Himalayan peaks. Nearby monasteries like Thiksey and Hemis showcase exquisite art and spirituality.Adventure enthusiasts flock to Leh for trekking in the remote valleys, river rafting in the Indus River, and exploring the otherworldly landscapes of the Nubra Valley and Pangong Lake. The region's Ladakhi culture, with its vibrant festivals and warm hospitality, adds to the charm of Leh.","Jammu, the winter capital of Jammu and Kashmir, is a city steeped in history and spirituality. The historic Raghunath Temple, with its impressive architecture, is a prominent landmark. The Ranbireshwar Temple is another architectural marvel dedicated to Lord Shiva. Jammu serves as the base for the sacred pilgrimage to Vaishno Devi, one of the most revered Hindu shrines in India. The city's bustling markets, vibrant culture, and delicious cuisine add to its charm and appeal.","Sonmarg, meaning the Meadow of Gold, is a serene valley surrounded by glaciers and snow-capped peaks. It serves as the starting point for the famous Amarnath Yatra pilgrimage, attracting pilgrims from all over the country. The Thajiwas Glacier, with its pristine beauty, is a popular attraction. The Zoji La Pass, a high mountain pass, connects Sonmarg to Leh and provides access to breathtaking vistas of the region.","Vaishno Devi is a sacred pilgrimage destination nestled in the Trikuta Mountains of Jammu and Kashmir. The shrine of Mata Vaishno Devi, a manifestation of the Hindu goddess Mahalakshmi, attracts millions of devotees each year. Pilgrims embark on a challenging trek to reach the sacred Amarnath Cave, seeking the blessings of the goddess. The journey is a profound spiritual experience, with devotees undertaking it with unwavering faith.","Doda is a picturesque district in Jammu and Kashmir known for its stunning landscapes, including lush valleys and dense forests. The region offers opportunities for trekking and exploring the natural beauty of the region. Doda is a peaceful destination for those seeking a serene escape in the lap of nature.","Kathua, a historic town in Jammu and Kashmir, is known for its rich cultural heritage and scenic beauty. The town is home to the enchanting Jasrota Fort, which reflects the region's historical significance. The revered Mata Sundrikote Temple is a significant religious site. Kathua offers a glimpse into the rich history, traditions, and spirituality of the region."
    ]
    var JammuKashmirBestTimeToVisit: [String] = [
        "April to October",
        "April to November",
        "April to November",
        "May to September",
        "May to October",
        "September to April",
        "May to September ",
        "Throughout the year",
        "April to October",
        "October to March"
    ]
    var JammuKashmirPeakTimeToVisit: [String] = [
        "May to September",
        "December to February)",
        "April to June and September to November",
        "July to August",
        "May to September",
        "October to March",
        "May to June and September",
        "March to October",
        "April to June and September to October",
        "October to February"
    ]
    var JammuKashmirTripDurations: [String] = [
        "2-4 days",
        "2-3 days",
        "2-3 days",
        "5-7 days",
        "2-3 days",
        "2-3 days",
        "2-3 days",
        "2-3 days",
        "2-3 days",
        "2-3 days"
    ]
//Mark : Uttar Pardesh
    var UttarPradeshPlacesNames: [String] = [
        "Taj Mahal",
        "Varanasi",
        "Fatehpur Sikri",
        "Ayodhya",
        "Mathura and Vrindavan",
        "Allahabad",
        "Lucknow",
        "Agra Fort",
        "Sarnath",
        "Kanpur"
    ]
    var imgUP : [String] = ["ic_Taj_Mahal","ic_Varanasi","ic_Fatehpur_Sikri","ic_Ayodhya","ic_Mathura_Vrindavan","ic_Allahabad","ic_Lucknow","ic_Agra_Fort","ic_Sarnath","ic_Kanpur"]
    var UttarPradeshPlaceDescriptions: [String] = [
      "The Taj Mahal stands as an eternal symbol of love and architectural grandeur. Located in Agra, it is one of the most iconic and recognizable landmarks globally. Built by Emperor Shah Jahan in the 17th century in memory of his beloved wife Mumtaz Mahal, this masterpiece of Mughal architecture is a testament to the enduring power of love. The Taj Mahal's stunning white marble façade is adorned with intricate inlay work, featuring precious gemstones and delicate floral motifs. The central mausoleum houses the tombs of Shah Jahan and Mumtaz Mahal, and it radiates a sense of serenity and beauty that captivates visitors from around the world. The Taj Mahal's allure is heightened during sunrise and sunset when the changing hues of the marble create a mesmerizing and unforgettable spectacle.","Varanasi, often referred to as Benares, is one of the world's oldest continuously inhabited cities, a spiritual epicenter, and a cradle of Indian culture and tradition. Situated on the banks of the sacred Ganges River, Varanasi is a place of profound spirituality and devotion. The city is famous for its numerous ghats, where pilgrims and devotees gather to perform rituals, offer prayers, and seek salvation. The mesmerizing Ganga Aarti, a nightly ritual performed at the Dashashwamedh Ghat, is a captivating spectacle that resonates with the deep spiritual essence of Varanasi.","Fatehpur Sikri, a UNESCO World Heritage site, is a historical gem located near Agra. Built during the reign of Emperor Akbar in the 16th century, it served as the Mughal capital for a brief but glorious period. The city's architecture is a testament to Akbar's vision and the fusion of Mughal and Persian styles. Prominent attractions include the Buland Darwaza, a colossal gateway that stands as an architectural marvel, the Jama Masjid, one of the largest mosques in India, and the Tomb of Sheikh Salim Chishti, known for its exquisite marble craftsmanship and spiritual significance. Fatehpur Sikri's grandeur and historical importance make it a must-visit destination for those seeking to explore India's rich heritage.","Ayodhya, a city steeped in religious and mythological significance, holds a special place in the hearts of millions of Hindus around the world. It is revered as the birthplace of Lord Rama, the central figure in the epic Ramayana. Ayodhya is adorned with numerous temples, each dedicated to different aspects of Lord Rama's life and his divine consort, Sita. Among the prominent temples is the Hanuman Garhi, dedicated to Lord Hanuman, the faithful devotee of Lord Rama. The Kanak Bhavan, another significant temple, is believed to be a gift from Lord Rama to his beloved queen, Sita .One of the most culturally significant events in Ayodhya is the celebration of Diwali, the Festival of Lights. The city comes alive with grand festivities and elaborate decorations during this time, symbolizing the return of Lord Rama to Ayodhya after his triumphant victory over the demon king Ravana. Ayodhya offers a unique opportunity to immerse oneself in the rich tapestry of Hindu mythology and spirituality.","Mathura, the birthplace of Lord Krishna, and Vrindavan, where Lord Krishna spent his childhood, are two sacred cities that reverberate with devotion and spiritual fervor. Mathura is known for its Krishna Janmabhoomi Temple, which marks the exact spot where Lord Krishna is believed to have been born. The Dwarkadhish Temple, dedicated to Lord Krishna, is another prominent attraction.Vrindavan, just a short drive from Mathura, is a place of enchantment where Lord Krishna is said to have performed his divine plays (leelas). The town is home to countless temples, each celebrating a different aspect of Lord Krishna's life. Among the most famous is the Banke Bihari Temple, where Lord Krishna is believed to appear in the form of a beloved child. The ISKCON Temple, dedicated to the International Society for Krishna Consciousness, is a hub of spiritual activity.","Allahabad, now officially known as Prayagraj, is a city of profound religious and cultural significance. It is located at the confluence of the Ganges, Yamuna, and mythical Saraswati rivers. This confluence, known as the Sangam, is considered one of the holiest places in Hinduism and is believed to be the site where Lord Brahma performed the first yajna (sacrifice) of creation.The city is renowned for hosting the Kumbh Mela, the largest peaceful gathering of humanity on Earth, which takes place every 12 years. During this mega-event, millions of pilgrims and seekers of spiritual enlightenment gather to take a holy dip in the sacred rivers and partake in various rituals and ceremonies.Allahabad is also home to historical sites such as the Allahabad Fort, built by Emperor Akbar, and the Anand Bhavan, the former residence of the Nehru-Gandhi family and a significant landmark in the Indian independence movement.The city's unique blend of spirituality, culture, and history makes it a place of immense significance for travelers seeking a deeper understanding of India's diverse tapestry.","Lucknow, the capital of Uttar Pradesh, is a city that beautifully blends history, culture, and culinary delights. It is often referred to as the City of Nawabs due to its rich Nawabi heritage and the influence of Mughal and Persian cultures.Lucknow boasts an architectural legacy that includes gems like the Bara Imambara, a grand structure with a central hall that is one of the largest arched constructions without support beams. The Chota Imambara, adorned with intricate chandeliers and mirror work, is another architectural marvel.The city's cuisine is renowned throughout India and beyond. Lucknow is famous for its kebabs, particularly the succulent and flavorful Galouti Kebabs. The Lucknawi biryani, a fragrant and aromatic rice dish, is a culinary delight. Additionally, the city's sweets, including the iconic Tunday Kababi and mouthwatering Malai ki Gilori, are a treat for the taste buds.Lucknow is also known for its traditional arts and crafts, with Chikankari embroidery being one of its signature offerings. Visitors can explore bustling markets, heritage sites, and immerse themselves in the city's vibrant cultural scene.","The Agra Fort, a UNESCO World Heritage site, is a majestic red sandstone fortress located in Agra, just a stone's throw away from the Taj Mahal. It served as the main residence of the Mughal emperors, including Akbar, Jahangir, and Shah Jahan. The fort's architecture is a remarkable fusion of Islamic, Persian, and Indian styles.The Agra Fort houses several magnificent structures, including the Diwan-i-Am (Hall of Public Audience), where the emperor would meet his subjects, and the Diwan-i-Khas (Hall of Private Audience), a place for more private discussions. The Sheesh Mahal (Mirror Palace) features intricate mirror work, and the Jahangiri Mahal is a fine example of Persian architecture.From the Agra Fort, visitors can enjoy breathtaking views of the Taj Mahal, which stands in all its glory across the Yamuna River.","Sarnath, a tranquil and sacred destination located near Varanasi, holds immense importance in Buddhism as the place where Lord Buddha gave his first sermon after attaining enlightenment. This event, known as the Dhammacakkappavattana Sutta, marked the beginning of Buddha's teachings to his five disciples.The Dhamek Stupa, a massive and intricately carved structure, stands as a symbol of the Buddha's enlightenment and attracts pilgrims and tourists alike. The Mulagandha Kuti Vihar is a beautiful temple with frescoes depicting scenes from the Buddha's life. The Ashoka Pillar, erected by Emperor Ashoka in the 3rd century BCE, is a significant historical artifact and a symbol of the spread of Buddhism.Sarnath's serene ambiance, lush gardens, and the presence of numerous meditation centers make it an ideal place for spiritual reflection and meditation.","Kanpur, an industrial city in Uttar Pradesh, is known for its economic significance and educational institutions. It is home to the prestigious Indian Institute of Technology (IIT) Kanpur, which has garnered international recognition for its academic excellence and research contributions.The city's industrial landscape includes prominent industries such as textiles, leather, and chemicals, making Kanpur an important hub for manufacturing and trade in northern India.Kanpur also has its share of historical and cultural attractions. The Kanpur Memorial Church, also known as the All Souls' Cathedral, is a solemn and beautiful structure that serves as a memorial to British soldiers who lost their lives during the 1857 Indian Rebellion. The Phool Bagh, a historical garden, showcases elegant architecture and lush greenery.While Kanpur is often associated with its industrial prowess, it is also a city that offers a diverse cultural experience and opportunities for education and innovation.These detailed descriptions provide an in-depth look at the rich history, culture, and significance of each of these places in Uttar Pradesh, India."
    ]
    var UttarPradeshBestTimeToVisit: [String] = [
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March"
    ]
    var UttarPradeshPeakTimeToVisit: [String] = [
        "November to February",
        "November to February",
        "November to February",
        "November to February",
        "November to February",
        "January to February (during Kumbh Mela)",
        "November to February",
        "November to February",
        "November to February",
        "November to February"
    ]
    var UttarPradeshTripDurations: [String] = [
        "1-2 days",
        "2-3 days",
        "1 day",
        "1-2 days",
        "1-2 days",
        "2-3 days",
        "1-2 days",
        "1 day",
        "1 day",
        "1 day"
    ]
//MArk Delhi Data

    var DelhiPlacesNames: [String] = [
        "India Gate",
        "Qutub Minar",
        "Red Fort",
        "Humayun's Tomb",
        "Lotus Temple",
        "Akshardham Temple",
        "Raj Ghat",
        "Jama Masjid",
        "Connaught Place",
        "National Gallery of Modern Art"
    ]
    var imgDelhi : [String] = ["ic_India_Gate","ic_Qutub_Minar","ic_Red_Fort","ic_Humayun'sTomb","ic_LotusTemple","ic_AkshardhamTemple","ic_RajGhat","ic_JamaMasjid","ic_Connaught Place","ic_National_Gallery"]
    var DelhiPlaceDescriptions: [String] = [
        "India Gate is an iconic war memorial located in the heart of New Delhi. This magnificent structure was built in 1931 to honor the memory of Indian soldiers who made the ultimate sacrifice during World War I. Designed by Sir Edwin Lutyens, the India Gate stands as a solemn tribute to the valor and sacrifice of these soldiers. The arch-shaped monument is constructed of sandstone and rises to a height of 42 meters. At the center of India Gate, an eternal flame known as the Amar Jawan Jyoti perpetually burns in memory of the unknown soldiers. The lush lawns surrounding the monument provide a peaceful setting for reflection and picnics, making it a popular spot for both locals and tourists.","The Qutub Minar, a UNESCO World Heritage site, is one of Delhi's most iconic landmarks and a masterpiece of Indo-Islamic architecture. Standing proudly in the Mehrauli area, it is the tallest brick minaret in the world, soaring to a height of 72.5 meters. The construction of the Qutub Minar was initiated by Qutb-ud-din Aibak in the 12th century and later completed by Iltutmish and Firoz Shah Tughlaq. The minaret is adorned with intricate calligraphy and decorative elements, including verses from the Quran. It is surrounded by a complex that includes the Quwwat-ul-Islam Mosque, one of the earliest mosques in India, and several other historical structures, making it a significant historical and architectural site.","The Red Fort, also known as Lal Qila, is a UNESCO World Heritage site and one of Delhi's most iconic monuments. Built by Emperor Shah Jahan in the mid-17th century, it served as the main residence of the Mughal emperors for over two centuries. The fort is an architectural marvel, constructed of red sandstone and featuring intricate marble inlays. Its design incorporates elements of Persian, Timurid, and Indian architecture.The Red Fort is known for its impressive Diwan-i-Am (Hall of Public Audience) and Diwan-i-Khas (Hall of Private Audience), where the emperor conducted state affairs. The Moti Masjid (Pearl Mosque) within the fort complex is a stunning example of Mughal architecture. Every year, on India's Independence Day (August 15), the Prime Minister hoists the national flag at the Red Fort and delivers a speech from its ramparts, making it a symbol of national pride and independence.","Humayun's Tomb is another UNESCO World Heritage site and a splendid Mughal architectural marvel located in the Nizamuddin East area of Delhi. It was built in the mid-16th century and is often regarded as a precursor to the Taj Mahal due to its exquisite design. The tomb is dedicated to Emperor Humayun and is surrounded by lush gardens, water channels, and intricate Mughal-style charbagh (four-part) landscaping. The main mausoleum is a symmetrical structure constructed of red sandstone and white marble, featuring intricate geometric patterns and calligraphy. The tomb's tranquil ambiance and beautiful architecture make it a peaceful oasis in the bustling city.","The Lotus Temple, also known as the Bahá'í House of Worship, is a unique and contemporary architectural masterpiece located in South Delhi. Shaped like a lotus flower, it is one of the most visited religious buildings in the world and serves as a Bahá'í House of Worship, welcoming people of all faiths. The temple's white marble exterior is surrounded by pristine pools and lush gardens. Inside, the central hall is a place for silent meditation and prayer. The Lotus Temple's distinctive and striking design has earned it several architectural awards, and it stands as a symbol of unity and peace.","Akshardham Temple, officially known as the Swaminarayan Akshardham Temple, is a modern marvel of architectural and cultural significance in Delhi. Opened in 2005, this grand temple complex showcases the rich heritage and spirituality of India's ancient traditions. The central monument is an intricately carved pink sandstone structure that houses the deity Swaminarayan. Surrounding the temple are beautifully landscaped gardens, sculptures, and an educational exhibition that traces the history and values of India's cultural heritage. Akshardham Temple is not only a place of worship but also a cultural and spiritual center that provides a unique and immersive experience for visitors.","Raj Ghat is a solemn and historic memorial located on the banks of the Yamuna River. It is the final resting place of Mahatma Gandhi, the Father of the Nation. The memorial consists of a simple black marble platform marking the spot where Gandhi was cremated in 1948. It is surrounded by a serene garden and trees, creating an atmosphere of peace and contemplation. Visitors pay their respects to the Mahatma by placing floral tributes at the site. Raj Ghat is not only a tribute to Gandhi's life and philosophy but also a symbol of India's commitment to non-violence and freedom.","Jama Masjid, also known as the Masjid-i-Jahan-Numa, is one of India's largest mosques and a magnificent example of Mughal architecture. Built by Emperor Shah Jahan in the 17th century, it is located in Old Delhi and can accommodate thousands of worshippers. The mosque's grandeur is evident in its red sandstone and white marble construction, domes, minarets, and vast courtyard. Visitors can climb the minarets for panoramic views of Delhi. The Jama Masjid continues to be an important place of worship and a symbol of Delhi's rich historical and cultural heritage.","Connaught Place, often referred to as CP, is a bustling commercial and cultural hub in the heart of New Delhi. It is renowned for its circular layout and Georgian architecture. CP is home to numerous shops, restaurants, cafes, theaters, and cultural centers. It's a popular destination for shopping, dining, and entertainment. The inner circle is surrounded by a variety of stores, while the outer circle is dotted with restaurants offering cuisines from around the world. Connaught Place is not only a shopper's paradise but also a place where locals and tourists come to soak in the city's vibrant atmosphere.","The National Gallery of Modern Art, located in New Delhi, is a treasure trove of contemporary and modern Indian art. It houses an extensive collection of paintings, sculptures, and other forms of visual art. The museum showcases the evolution of Indian art from the late 18th century to the present day. The NGMA hosts rotating exhibitions and installations, featuring works by renowned Indian artists as well as international contemporary artists. It is a cultural haven for art enthusiasts and a place where visitors can explore the divers"
    ]
    var DelhiBestTimeToVisit: [String] = [
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March"
    ]
    var DelhiPeakTimeToVisit: [String] = [
        "November to February",
        "November to February",
        "November to February",
        "November to February",
        "November to February",
        "November to February",
        "November to February",
        "November to February",
        "November to February",
        "November to February"
    ]
    var DelhiTripDurations: [String] = [
        "1-2 days",
        "1-2 days",
        "1-2 days",
        "1-2 days",
        "1 day",
        "1-2 days",
        "Half a day",
        "Half a day",
        "1-2 days",
        "Half a day"
    ]

    //MArk : Ladakh Data
    var LadakhPlacesNames: [String] = [
        "Pangong Lake",
        "Nubra Valley",
        "Leh Palace",
        "Hemis Monastery",
        "Tso Moriri Lake",
        "Zanskar Valley",
        "Thiksey Monastery",
        "Diskit Monastery",
        "Shanti Stupa",
        "Lamayuru Monastery"
    ]
    var imgLadak : [String] = ["ic_PangongLake","ic_NubraValley","ic_LehPalace","ic_Hemis_Monastery","ic_Ts _Moriri_Lak","ic_Zanskar_Valley","ic_Thiksey_Monastery","ic_Diskit_Monastery","ic_Shanti_Stupa","ic_Lamayuru_Monastery"]
    var LadakhPlaceDescriptions: [String] = [
        "Pangong Lake, often referred to as Pangong Tso, is a mesmerizing high-altitude lake located in the Ladakh region. Nestled at an elevation of approximately 4,350 meters above sea level, this breathtaking lake stretches across India and extends into Tibet, China. What makes Pangong Lake truly captivating is its ever-changing shades of blue, which range from deep cobalt to turquoise, depending on the sunlight and weather conditions. Surrounded by stark, rugged mountains, Pangong Lake offers a surreal and ethereal landscape. The lake gained international fame after featuring in the Bollywood movie 3 Idiots. Visitors can enjoy camping by the lakeside, taking in the pristine beauty and tranquility of this natural wonder.","Nubra Valley, often called the Valley of Flowers, is a picturesque region located in the northernmost part of Ladakh. It is renowned for its stark yet stunning landscapes, with lush green valleys, sand dunes, and a contrasting backdrop of snow-capped peaks. The valley is accessible via the world's highest motorable road, the Khardung La Pass. Nubra Valley offers opportunities for camel safaris on the double-humped Bactrian camels, visits to ancient monasteries like Diskit and Hunder, and serene walks along the Shyok River. The region provides a unique blend of natural beauty and cultural experiences.","Leh Palace, a historic architectural gem, graces the skyline of Leh, the largest town in Ladakh. Built in the 17th century by King Sengge Namgyal, the palace served as the royal residence for the Namgyal dynasty. The nine-story structure, with its massive walls and intricate woodwork, showcases a blend of Tibetan and Indian architectural styles. From the rooftop, visitors are treated to panoramic views of the Leh town and the surrounding Himalayan peaks. Although the palace is in a state of partial ruin, it remains a symbol of Ladakh's rich history and heritage.","Hemis Monastery, situated in the Hemis village, is one of the most significant and largest monasteries in Ladakh. It is known for its annual Hemis Festival, a vibrant celebration of Tibetan Buddhism that draws pilgrims and tourists alike. The monastery features an impressive collection of thangkas (Tibetan scroll paintings), ancient relics, and a massive copper statue of Lord Padmasambhava. Hemis Monastery is not only a spiritual center but also a place of cultural richness, surrounded by tranquil landscapes and serene ambiance.","Tso Moriri Lake, located in the Changthang region of Ladakh, is a high-altitude, pristine lake surrounded by towering mountains. Situated at an altitude of around 4,522 meters, it is the largest high-altitude lake in India. The azure waters of Tso Moriri reflect the clear blue sky, creating a surreal and enchanting sight. The lake is a haven for birdwatchers, with various species of migratory birds and wildlife frequenting its shores. Visitors can explore the nomadic culture of the region, as the Changpas, a semi-nomadic community, graze their livestock in the area.","Zanskar Valley, known for its remote and rugged terrain, is a paradise for adventure enthusiasts and nature lovers. Nestled amidst the Zanskar Range and the Great Himalayas, the valley offers trekking opportunities through dramatic landscapes, frozen rivers, and high mountain passes. The Zanskar River, frozen during the winter, provides the unique experience of the Chadar Trek, where trekkers walk on the ice. The region is also home to ancient monasteries, including Karsha and Phuktal, which are perched dramatically on cliffs.","Thiksey Monastery, perched atop a hill, is a striking religious complex that resembles the famed Potala Palace in Lhasa, Tibet. The monastery is known for its impressive Maitreya Buddha statue, which stands at 15 meters tall and is one of the largest such statues in Ladakh. Thiksey Monastery offers a serene ambiance for spiritual reflection and exploration of Tibetan Buddhism. Visitors can also enjoy panoramic views of the Indus Valley from this vantage point.","Diskit Monastery, located in the Nubra Valley, is an ancient and picturesque Tibetan Buddhist monastery. It is known for its stunning setting amidst sand dunes and rugged mountains. The monastery houses a massive statue of Maitreya Buddha, with its serene countenance overlooking the valley. Diskit Monastery provides a serene and peaceful atmosphere for meditation and spiritual contemplation.","Shanti Stupa, or the Peace Pagoda, is a symbol of peace and spirituality located atop a hill in Leh. Built by a Japanese Buddhist organization, the stupa offers panoramic views of the Leh town and the surrounding landscapes. Its white exterior and golden spire glisten in the sunlight. Visitors often come to Shanti Stupa to experience tranquility, meditate, and witness the stunning sunrises and sunsets over the Himalayas.","Lamayuru Monastery, perched on a hill in the Lamayuru village, is one of the oldest and most significant monasteries in Ladakh. It is known for its unique moonscape-like surroundings, with eroded rock formations that resemble a lunar landscape. The monastery is an important spiritual center and home to a vibrant monastic community. Visitors can explore the ancient prayer halls, murals, and enjoy the serene ambiance that pervades the area."
    ]
    var LadakhBestTimeToVisit: [String] = [
        "June to September",
        "June to September",
        "May to September",
        "June to September",
        "June to September",
        "June to September",
        "June to September",
        "June to September",
        "May to September",
        "June to September"
    ]
    var LadakhPeakTimeToVisit: [String] = [
        "July and August",
        "July and August",
        "June to August",
        "July",
        "July and August",
        "June to August",
        "July and August",
        "July and August",
        "June to August",
        "July and August"
    ]
    var LadakhTripDurations: [String] = [
        "2-3 days",
        "2-3 days",
        "1-2 days",
        "1 day (during the festival)",
        "1-2 days",
        "3-4 days",
        "1-2 days",
        "1-2 days",
        "Half a day",
        "1-2 days"
    ]


    @IBOutlet var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "CellC_OriginDetail", bundle: nil), forCellWithReuseIdentifier: "CellC_OriginDetail")
    }
}
extension UttrakhandVC : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let selectedIndex = selectedIndex{
            switch selectedIndex{
            case 0 :
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lbl_OriginTittle.text = ArrOriginTittle[indexPath.row]
                cell.lblPeakSeason.text = PeakSeason[indexPath.row]
                cell.lblTripDuration.text = ArrIdealTrip[indexPath.row]
                cell.lbl_stateName.text = "Uttrakhand"
                cell.lbl_bestTimeToVisit.text = ArrBestSeason[indexPath.row]
                cell.img_Origin.image =  UIImage(named: ArrImgNorth[indexPath.row])
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 1 :
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lbl_OriginTittle.text = ArrRajasthanPlaces[indexPath.row]
                cell.lblPeakSeason.text = ArrPeakSeasonRajasthan[indexPath.row]
                cell.lblTripDuration.text = ArrTripDurationsRajasthan[indexPath.row]
                cell.lbl_stateName.text = "Rajasthan"
                cell.lbl_bestTimeToVisit.text = ArrBestSeasonRajasthan[indexPath.row]
                cell.img_Origin.image =  UIImage(named: "ic_rajasthan")
                cell.img_Origin.image =  UIImage(named: imgRajasthan[indexPath.row])
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 2:
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lbl_OriginTittle.text = HimachalPlacesNames[indexPath.row]
                cell.lblPeakSeason.text = HimachalPeakTimeToVisit[indexPath.row]
                cell.lblTripDuration.text = HimachalTripDurations[indexPath.row]
                cell.lbl_stateName.text = "Himachal Pardesh"
                cell.lbl_bestTimeToVisit.text = HimachalBestTimeToVisit[indexPath.row]
                cell.img_Origin.image =  UIImage(named: "ic_rajasthan")
                cell.img_Origin.image =  UIImage(named: ImgHimachal[indexPath.row])
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 3 :
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lbl_OriginTittle.text = JammuKashmirPlacesNames[indexPath.row]
                cell.lblPeakSeason.text = JammuKashmirPeakTimeToVisit[indexPath.row]
                cell.lblTripDuration.text = JammuKashmirTripDurations[indexPath.row]
                cell.lbl_stateName.text = "Jammu & Kashmir"
                cell.lbl_bestTimeToVisit.text = JammuKashmirBestTimeToVisit[indexPath.row]
                cell.img_Origin.image =  UIImage(named: "ic_rajasthan")
                 cell.img_Origin.image =  UIImage(named: imgJammu[indexPath.row])
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 4 :
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lbl_OriginTittle.text = UttarPradeshPlacesNames[indexPath.row]
                cell.lblPeakSeason.text = UttarPradeshPeakTimeToVisit[indexPath.row]
                cell.lblTripDuration.text = UttarPradeshTripDurations[indexPath.row]
                cell.lbl_stateName.text = "Uttar Pardesh"
                cell.lbl_bestTimeToVisit.text = UttarPradeshBestTimeToVisit[indexPath.row]
                cell.img_Origin.image =  UIImage(named: "ic_rajasthan")
                cell.img_Origin.image =  UIImage(named: imgUP[indexPath.row])
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 5 :
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lbl_OriginTittle.text = DelhiPlacesNames[indexPath.row]
                cell.lblPeakSeason.text = DelhiPeakTimeToVisit[indexPath.row]
                cell.lblTripDuration.text = DelhiTripDurations[indexPath.row]
                cell.lbl_stateName.text = "Delhi"
                cell.lbl_bestTimeToVisit.text = DelhiBestTimeToVisit[indexPath.row]
                cell.img_Origin.image =  UIImage(named: imgDelhi[indexPath.row])
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 6 :
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lbl_OriginTittle.text = LadakhPlacesNames[indexPath.row]
                cell.lblPeakSeason.text = LadakhPeakTimeToVisit[indexPath.row]
                cell.lblTripDuration.text = LadakhTripDurations[indexPath.row]
                cell.lbl_stateName.text = "Ladakh"
                cell.lbl_bestTimeToVisit.text = LadakhBestTimeToVisit[indexPath.row]
                cell.img_Origin.image =  UIImage(named: imgLadak[indexPath.row])
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            default :
                return UICollectionViewCell()
            }
        }
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let selectedIndex = selectedIndex{
            switch selectedIndex{
            case 0 :
                return ArrOriginTittle.count
            case 1 :
                return ArrRajasthanPlaces.count
            case 2 :
                return HimachalPlacesNames.count
            case 3 :
                return JammuKashmirPlacesNames.count
            case 4 :
                return UttarPradeshPlacesNames.count
            case 5 :
                return DelhiPlacesNames.count
            case 6 :
                return LadakhPlacesNames.count
            default :
                return 0
            }
        }
        return 0
    }
        func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AboutDetailVC") as? AboutDetailVC
            if let selectedIndex = selectedIndex{
                switch selectedIndex{
                case 0:
                    vc?.NorthIndia = ArrOriginDetail[indexPath.row]
                    self.navigationController?.pushViewController(vc!, animated: true)
                case 1:
                    vc?.NorthIndia = ArrRajasthanPlaceDetails[indexPath.row]
                    self.navigationController?.pushViewController(vc!, animated: true)
                case 2:
                    vc?.NorthIndia = HimachalPlaceDescriptions[indexPath.row]
                    self.navigationController?.pushViewController(vc!, animated: true)
                case 3:
                    vc?.NorthIndia = JammuKashmirPlaceDescriptions[indexPath.row]
                    self.navigationController?.pushViewController(vc!, animated: true)
                case 4:
                    vc?.NorthIndia = UttarPradeshPlaceDescriptions[indexPath.row]
                    self.navigationController?.pushViewController(vc!, animated: true)
                case 5:
                    vc?.NorthIndia = DelhiPlaceDescriptions[indexPath.row]
                    self.navigationController?.pushViewController(vc!, animated: true)
                case 6:
                    vc?.NorthIndia = LadakhPlaceDescriptions[indexPath.row]
                    self.navigationController?.pushViewController(vc!, animated: true)
                default : break
                }
            }
           
        }
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
            if let selectedIndex = selectedIndex{
                switch selectedIndex{
                case 0 :
                    return 0
                case 1 :
                    return 0
                case 2 :
                    return 0
                case 3:
                    return 0
                case 4 :
                    return 0
                case 5 :
                    return 0
                case 6 :
                    return 0
                default :
                    return 0
                }

            }
            return 0.0
        }
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
            if let selectedIndex = selectedIndex{
                switch selectedIndex{
                case 0 :
                    return 0
                case 1 :
                    return 0
                case 2 :
                    return 0
                case 3:
                    return 0
                case 4 :
                    return 0
                case 5 :
                    return 0
                case 6 :
                    return 0
                default :
                    return 0
                }

            }
            return 0.0
        }
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            if let selectedIndex = selectedIndex{
                switch selectedIndex{
                case 0 :
                    let size = collectionView.bounds.width
                    return CGSize(width: size/1, height: size/1)
                case 1 :
                    let size = collectionView.bounds.width
                    return CGSize(width: size/1, height: size/1)
                case 2 :
                    let size = collectionView.bounds.width
                    return CGSize(width: size/1, height: size/1)
                case 3:
                    let size = collectionView.bounds.width
                    return CGSize(width: size/1, height: size/1)
                case 4 :
                    let size = collectionView.bounds.width
                    return CGSize(width: size/1, height: size/1)
                case 5 :
                    let size = collectionView.bounds.width
                    return CGSize(width: size/1, height: size/1)
                case 6 :
                    let size = collectionView.bounds.width
                    return CGSize(width: size/1, height: size/1)
                default :
                    return CGSize.zero
                }
                
            }
            return CGSize.zero
        }
    }
