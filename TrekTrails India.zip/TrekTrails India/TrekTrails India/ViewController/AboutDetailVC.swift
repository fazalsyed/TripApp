//
//  AboutDetailVC.swift
//  TrekTrails India
//
//  Created by syed fazal abbas on 04/09/23.
//

import UIKit

class AboutDetailVC: UIViewController {

    @IBOutlet var vwMain: UIView!
    var NorthIndia : String?
    var SouthIndia : String?
    var EastIndia : String?
    var WestIndia : String?
    var CentralIndia : String?
    @IBOutlet var txt_Detail: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
       UIView()
        if let NorthDetial = NorthIndia {
                    // Set the text view to display the museum detail
                    txt_Detail.text = NorthDetial
                }
        if let SouthDetial = SouthIndia {
                    // Set the text view to display the museum detail
                    txt_Detail.text = SouthDetial
                }
        if let EastDetial = EastIndia {
                    // Set the text view to display the museum detail
                    txt_Detail.text = EastDetial
                }
        if let WestDetial = WestIndia {
                    // Set the text view to display the museum detail
                    txt_Detail.text = WestDetial
                }
        if let CentralDetial = CentralIndia {
                    // Set the text view to display the museum detail
                    txt_Detail.text = CentralDetial
                }
    }
    
    func UIView(){
        vwMain.layer.cornerRadius = 8
        vwMain.layer.borderWidth = 1
        vwMain.layer.borderColor = UIColor.gray.cgColor
    }
}
