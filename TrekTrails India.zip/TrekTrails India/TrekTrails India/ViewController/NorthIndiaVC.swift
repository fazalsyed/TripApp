//
//  NorthIndiaVC.swift
//  TrekTrails India
//
//  Created by syed fazal abbas on 04/09/23.
//

import UIKit

class NorthIndiaVC: UIViewController {

    @IBOutlet var img_background: UIImageView!
    var ArrNameNorth : [String] = ["Uttarakhand","Rajasthan","Himachal","Jammu & Kashmir","Uttar Pradesh","Delhi","Ladakh"]
    var ArrImgNorth : [String] = ["ic_uttra","ic_rajasthan","ic_Himachal","ic_kashmir","ic_UP","ic_Delhi","ic_Ladakh"]
    @IBOutlet var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "CellC_Destination", bundle: nil), forCellWithReuseIdentifier: "CellC_Destination")
        img_background.layer.cornerRadius = 15
        img_background.layer.borderWidth = 1
        img_background.layer.borderColor = UIColor.gray.cgColor
        
    }
}
extension NorthIndiaVC : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return ArrNameNorth.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_Destination", for: indexPath) as! CellC_Destination
        cell.lbl_Destination.text = ArrNameNorth[indexPath.row]
        cell.img_Destination.image = UIImage(named: ArrImgNorth[indexPath.row])
        cell.img_Destination.layer.cornerRadius = 8
        cell.img_Destination.layer.borderWidth = 1
        cell.img_Destination.layer.borderColor = UIColor.gray.cgColor
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("Hello")
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "UttrakhandVC") as? UttrakhandVC
        vc?.selectedIndex = indexPath.row
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = collectionView.bounds.width
        return CGSize(width: size/2-6, height: size/2-6)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 2, left: 2, bottom: 0, right: 2)
    }
}
