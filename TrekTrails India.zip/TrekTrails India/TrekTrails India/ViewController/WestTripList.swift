//
//  WestTripList.swift
//  TrekTrails India
//
//  Created by syed fazal abbas on 08/09/23.
//

import UIKit

class WestTripList: UIViewController {

    var selctedIndex : Int?
    //Mark for Rajasthan
    var ArrRajasthanPlaces: [String] = ["Jaipur", "Udaipur", "Jodhpur", "Jaisalmer", "Pushkar", "Ranthambore", "Bikaner", "Ajmer", "Chittorgarh", "Mount Abu"]
    var imgRajasthan : [String] = ["ic_Jaipur","ic_Udaipur","ic_Jodhpur","ic_Jaisalmer","ic_Pushkar","ic_Ranthambore","ic_Bikaner","ic_Ajmer","ic_Chittorgarh","ic_Mount_Abu"]
    var ArrRajasthanPlaceDetails: [String] = [
        "Jaipur, the capital of Rajasthan, is a city steeped in history and culture. Known as the Pink City due to its distinctive pink sandstone buildings, Jaipur is a vibrant blend of tradition and modernity. The city is home to iconic landmarks such as the Hawa Mahal, a palace with intricate latticework, and the majestic Amer Fort, which offers panoramic views of the city. Jaipur is also famous for its bustling bazaars, where you can shop for textiles, jewelry, and handicrafts. The City Palace, a royal residence turned museum, showcases the opulent lifestyle of the Rajput kings. Jaipur is a must-visit destination for those seeking a glimpse of Rajasthan's regal heritage.","Udaipur, often referred to as the City of Lakes, is a picturesque gem in Rajasthan. Nestled amid the Aravalli hills, the city boasts several serene lakes, with Lake Pichola being the most famous. Udaipur's crowning jewel is the City Palace, a sprawling complex that offers breathtaking views of the lake and houses a museum displaying royal artifacts. The Lake Palace, seemingly floating on Lake Pichola, is an architectural marvel that has been converted into a luxurious hotel. Udaipur's narrow alleys are lined with colorful shops, art galleries, and rooftop restaurants, creating a romantic and enchanting atmosphere. The city's rich history and stunning architecture make it a favored destination for weddings and romantic getaways.","Jodhpur, known as the Blue City for its azure-painted houses in the old quarter, is a city that exudes charm and history. Dominating the skyline is Mehrangarh Fort, a colossal fortress perched on a rocky hill. Inside the fort, visitors can explore well-preserved palaces with intricate architecture and a museum showcasing royal artifacts. The Jaswant Thada, a marble cenotaph, stands as a serene memorial to the former rulers of Jodhpur. Stroll through the bustling streets of the old city, where vendors sell textiles, spices, and handicrafts. The Clock Tower and Sardar Market are popular landmarks in this vibrant city. Jodhpur's rich cultural heritage and warm hospitality make it a captivating destination.","Jaisalmer, often referred to as the Golden City, is a desert oasis known for its stunning sand dunes and golden-hued architecture. At the heart of the city stands the majestic Jaisalmer Fort, a UNESCO World Heritage Site, characterized by its intricate carvings and imposing walls. Inside the fort, visitors can explore palaces, Jain temples, and havelis adorned with exquisite designs. Beyond the fort, the Thar Desert beckons, offering camel safaris that allow travelers to experience the stark beauty of the sand dunes and witness captivating sunsets. The city's narrow lanes are","Pushkar, a sacred town nestled around a serene lake, is a place of spiritual significance and cultural richness. The Brahma Temple, dedicated to Lord Brahma, the creator of the universe, is one of the few in the world. The Pushkar Lake, surrounded by ghats, attracts pilgrims who come to take a holy dip. Pushkar is also famous for its annual camel fair, where traders and tourists converge for a vibrant spectacle of colors, traditions, and livestock trading. The town's relaxed vibe, spiritual aura, and lively markets make it a unique destination in Rajasthan.","Ranthambore is a wildlife enthusiast's paradise, home to the majestic Bengal tiger. The Ranthambore National Park, set against the backdrop of the historic Ranthambore Fort, offers thrilling jungle safaris. Visitors can spot a variety of wildlife, including leopards, deer, and crocodiles, while exploring the ruins of the ancient fort. Ranthambore is a harmonious blend of nature and history, providing a unique and exhilarating experience for those seeking encounters with India's incredible wildlife.","Bikaner is a city steeped in history and renowned for its exquisite architecture and delectable cuisine. The Junagarh Fort, a formidable structure, showcases stunning palaces, courtyards, and temples. Bikaner is also famous for its spicy snacks, especially the world-famous bhujia The city's old bazaars offer a glimpse into its rich heritage, with handicrafts, jewelry, and textiles that reflect the craftsmanship of the region. Bikaner's blend of history and gastronomy makes it a unique destination in Rajasthan.","Ajmer, a city of spiritual significance, is known for the Ajmer Sharif Dargah, a Sufi shrine dedicated to Khwaja Moinuddin Chishti. Pilgrims from various faiths visit this revered site seeking blessings and spiritual solace. The city also boasts serene lakes like Ana Sagar Lake, where one can enjoy leisurely boat rides and peaceful moments. Ajmer's tranquil ambiance and cultural richness offer a unique experience for those exploring Rajasthan's spiritual heritage.","Chittorgarh is a city steeped in history, dominated by the grandeur of the Chittorgarh Fort, one of the largest forts in India and a UNESCO World Heritage Site. This fort is a testament to the valor and sacrifice of Rajput warriors. Exploring its massive walls, palaces, and temples transports visitors to a bygone era. Chittorgarh's historical significance and architectural marvels make it a must-visit destination for history enthusiasts.","Mount Abu is a refreshing retreat in the heart of Rajasthan, offering respite from the desert heat. As Rajasthan's only hill station, it boasts a cool and pleasant climate year-round. Nakki Lake, surrounded by lush greenery, is a serene spot for boating. The Dilwara Jain Temples, with their intricate marble carvings, are architectural wonders. Mount Abu offers scenic viewpoints like Sunset Point and Guru Shikhar, the highest peak in the Aravalli Range. This hill station provides a peaceful and scenic escape, making it a unique destination in Rajasthan."]
    
    var ArrBestSeasonRajasthan : [String] = [
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to June",
        "October to March",
        "October to March",
        "October to March",
        "April to June"
    ]
    var ArrPeakSeasonRajasthan: [String] = [
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to March",
        "October to June ",
        "October to March",
        "October to March",
        "October to March",
        "April to June "
    ]
    var ArrTripDurationsRajasthan: [String] = [
        "2-3 days",
        "2-4 days",
        "2-3 days",
        "2-3 days",
        "1-2 days ",
        "2-3 days",
        "1-2 days",
        "1 day",
        "1-2 days",
        "2-3 days"
    ]
    //Marks : Goa Detail Array
   var arrGoaplacename = ["Calangute Beach", "Baga Beach", "Anjuna Beach", "Fort Aguada", "Basilica of Bom Jesus", "Dudhsagar Waterfalls", "Palolem Beach", "Dona Paula", "Arambol Beach", "Chapora Fort"]
    var imgGoa : [String] = ["ic_Calangute_Beach","ic_Baga_Beach","ic_Anjuna_Beach","ic_Fort_Aguada","ic_Basilica_Bom_Jesus","ic_Dudhsagar_Waterfalls","ic_Palolem_Beach","ic_Dona_Paula","ic_Arambol_Beach","ic_Chapora_Fort"]
    var arrGoatripduration = ["2-3 days", "2-3 days", "2-3 days", "1 day", "1 day", "1 day", "2-3 days", "1-2 hours", "2-3 days", "1-2 hours"]
   var  arrGoabestseason = ["November to February", "November to February", "November to February", "October to March", "October to March", "June to September", "November to February", "October to March", "November to February", "October to March"]
    var arrGoapeakseason = ["December to January", "December to January", "December to January", "December to January", "December to January", "October to November", "December to January", "December to January", "December to January", "December to January"]
    var arrGoaDetail : [String] = ["Nestled in the heart of North Goa, Calangute Beach reigns as the largest and most popular of Goa's coastal jewels. Often hailed as the Queen of Beaches, Calangute's expanse of golden sands stretches for miles, inviting sun-seekers, adventure enthusiasts, and those simply yearning for a leisurely stroll along the shore. The azure waters are inviting for swimmers, while thrill-seekers can partake in a variety of water sports, from parasailing to jet-skiing. The beachfront is dotted with an array of vibrant beach shacks, where one can relish fresh, local cuisine and sip on tropical concoctions. As the sun sets, Calangute awakens with a pulsating energy, as the coastline transforms into a nightlife hub, featuring an array of clubs, bars, and live music venues.","Adjacent to Calangute, Baga Beach presents a vibrant contrast to its neighbor's laid-back ambiance. This sandy stretch is synonymous with exhilarating water sports, beckoning adventure enthusiasts to indulge in activities like parasailing, banana boat rides, and jet-skiing. The beachscape is further adorned with an eclectic mix of beach shacks and restaurants, where one can savor delectable Goan seafood while reveling in live music performances. Baga's nightlife is equally electrifying, with a host of beachfront clubs and bars setting the stage for an unforgettable evening.","Adjacent to Calangute, Baga Beach presents a vibrant contrast to its neighbor's laid-back ambiance. This sandy stretch is synonymous with exhilarating water sports, beckoning adventure enthusiasts to indulge in activities like parasailing, banana boat rides, and jet-skiing. The beachscape is further adorned with an eclectic mix of beach shacks and restaurants, where one can savor delectable Goan seafood while reveling in live music performances. Baga's nightlife is equally electrifying, with a host of beachfront clubs and bars setting the stage for an unforgettable evening.","Perched atop a hill overlooking the Arabian Sea, Fort Aguada stands as a sentinel to Goa's rich maritime past. Constructed in the 17th century by the Portuguese, its robust bastions and well-preserved architecture offer a captivating glimpse into Goa's colonial history. The fort's lighthouse, still guiding ships today, lends an air of mystique to this historic site. Panoramic views from its ramparts afford a breathtaking panorama of the coast.","This UNESCO World Heritage site is a cornerstone of Goa's spiritual and architectural legacy. The Basilica of Bom Jesus, a jewel of 16th-century architecture, enshrines the mortal remains of St. Francis Xavier. Its Baroque interiors are a testament to the craftsmanship of yesteryears, adorned with ornate altars and religious artworks. Here, the palpable sense of devotion harmonizes with a profound appreciation for art and history.","Hidden amidst the lush expanses of the Bhagwan Mahavir Wildlife Sanctuary, Dudhsagar Waterfalls cascade dramatically, their milky waters plunging over 300 meters. Accessible through an adventurous trek, a thrilling jeep safari, or a scenic train ride through the Western Ghats, the journey to Dudhsagar is as much a part of the experience as the awe-inspiring sight of the falls itself. The surrounding flora and fauna further enhance the allure of this natural wonder.","In the serene embrace of South Goa lies Palolem Beach, a crescent-shaped haven of tranquility. Fringed with swaying palms, the beach's soft sands invite relaxation and contemplation. The calm waters offer an idyllic setting for a leisurely swim, while boat trips to nearby islands and coves promise exploratory adventures. Palolem's beachfront shacks beckon with delectable Goan cuisine, ensuring that every sense is satiated.","This picturesque viewpoint, where the Mandovi and Zuari rivers converge with the Arabian Sea, is steeped in romance and legend. The viewpoint offers uninterrupted views of the sea and coastline, making it a popular destination for couples and wanderers. Named after the tragic love story of Dona Paula de Menezes, statues immortalize the enduring spirit of romance that graces this location.","Arambol Beach is a sanctuary for free spirits and seekers of creative expression. Surrounded by rugged cliffs, this beach radiates a sense of serenity and freedom. Drum circles, yoga retreats, and holistic healing centers punctuate the tranquil ambiance, welcoming those in search of a bohemian lifestyle.","Eternally perched on a hill, Chapora Fort extends panoramic views of the Arabian Sea and the picturesque surrounding landscape. A testament to the historical tapestry of Goa, the fort's timeworn ramparts and remnants stand as silent sentinels of the past. This evocative site is a pilgrimage for history buffs and adventurers, offering a portal into a bygone era."]
    
   //Marks : Detail About Maharashtra
    var arrMumbaiPlaceName: [String] = ["Gateway of India", "Chhatrapati Shivaji Maharaj Terminus", "Marine Drive", "Elephanta Caves", "Juhu Beach"]
    var imgMumbai : [String] = ["ic_GatewaIndia","ic_Chhatrapati","ic_Marine_Drive","ic_Elephanta_Caves","ic_Juhu_Beach"]
var arrMumbaiTripDuration: [String] = ["1-2 hours", "1-2 hours", "1-2 hours", "Half-day trip", "1-2 hours"]
var arrMumbaiBestSeason: [String] =  ["October to March", "October to March", "October to March", "October to March", "October to March"]
var arrMubaiPeakSeason: [String] = ["November to February", "November to February", "November to February", "November to February", "November to February"]
    var arrMumbaiDetail : [String] = ["The Gateway of India is an iconic and historically significant monument situated in the bustling city of Mumbai. This grand archway stands proudly overlooking the Arabian Sea, serving as a symbol of India's rich history and enduring spirit. Built to commemorate the visit of King George V and Queen Mary in 1911, the Gateway of India is a splendid example of Indo-Saracenic architecture. Its intricate designs, ornate details, and imposing structure make it a must-visit attraction. Visitors can leisurely stroll along the waterfront promenade, taking in the refreshing sea breeze and gazing at the picturesque views of the sea. The area around the Gateway of India is often bustling with tourists and locals alike, making it a lively spot to soak in the vibrant atmosphere of Mumbai. You can also embark on boat rides from here to explore nearby attractions, including the historic Elephanta Caves.","Formerly known as Victoria Terminus (VT), Chhatrapati Shivaji Maharaj Terminus is not just a railway station but a true architectural gem that adds to the grandeur of Mumbai. This UNESCO World Heritage Site boasts stunning Victorian Gothic architecture, characterized by its ornate facades, pointed arches, and intricate details. The station is a bustling hub of activity, with commuters rushing to catch trains, but it's also a destination for architecture enthusiasts and history buffs. The interiors are equally impressive, with soaring ceilings, stained glass windows, and a stunning central dome that creates a sense of grandeur. Whether you're catching a train or simply visiting to appreciate its architectural splendor, CSMT is a testament to Mumbai's rich heritage.","Marine Drive, often referred to as the Queen's Necklace, is a picturesque promenade that curves along the coastline of Mumbai. This iconic stretch of road is famous for its unique semicircular shape and the way it lights up at night, resembling a string of pearls adorning the city. Marine Drive is a favorite spot for both locals and tourists to take leisurely evening walks while enjoying the breathtaking views of the Arabian Sea. The promenade is lined with art deco-style buildings and palm trees, adding to its charm. Whether you're here to watch a mesmerizing sunset, engage in some people-watching, or simply unwind by the sea, Marine Drive offers a serene escape from the hustle and bustle of Mumbai.","The Elephanta Caves, situated on Elephanta Island in Mumbai's harbor, are an archaeological wonder and a UNESCO World Heritage Site. These rock-cut caves date back to the 5th to 7th centuries and are renowned for their intricate sculptures and rich history. The main cave, known as the Great Cave, houses remarkable carvings depicting Hindu deities, mythological stories, and intricate patterns. The centerpiece is a colossal three-headed sculpture of Lord Shiva, a sight that leaves visitors in awe. The island itself offers a serene escape from the city, with lush greenery and panoramic views of the Arabian Sea. To reach Elephanta Island, visitors can take a short ferry ride from the Gateway of India, adding to the adventure of exploring this ancient site.","Juhu Beach is a beloved destination for both locals and visitors seeking a slice of beachfront relaxation in the heart of Mumbai. This long and sandy shoreline stretches along the Arabian Sea, offering a peaceful escape from the city's hustle and bustle. Visitors can take leisurely strolls along the beach, savor delicious street food from vendors, and watch the mesmerizing sunset over the horizon. Juhu Beach is a vibrant spot, often bustling with families, couples, and tourists enjoying the salty sea breeze. It's also home to a variety of recreational activities and cultural events, making it a versatile and entertaining destination for all."]

    //Marks : Pune Array Detail
    var arrPunePlaceName: [String] = ["Aga Khan Palace", "Shaniwar Wada", "Sinhagad Fort", "Osho Ashram", "Dagdusheth Halwai Ganpati Temple"]
    var imgPune : [String] = ["ic_AgaKhanPalace","ic_Shaniwar_Wada","ic_SinhagadFort","ic_OshoAshram","ic_Dagdusheth"]
var arrPuneTripDuration: [String] = ["1-2 hours", "2-3 hours", "Half-day trip", "2-3 hours", "1-2 hours"]
var arrPuneBestSeason: [String] =  ["October to March", "October to March", "June to March", "October to March", "October to March"]
var arrPunePeakSeason: [String] = ["October to March", "October to March", "October to March", "October to March", "October to March"]
    var arrPuneDetails : [String] = ["The Aga Khan Palace is a historic monument located in Pune. It holds great significance in India's struggle for independence as it served as a prison for several freedom fighters, including Mahatma Gandhi. The palace is known for its elegant architecture, including Italian arches and spacious lawns. Visitors can explore the museum inside the palace, which houses exhibitions related to the life and times of Mahatma Gandhi. The serene surroundings and historical importance make the Aga Khan Palace a must-visit attraction in Pune.","Shaniwar Wada is a grand fortification and palace complex in Pune. It was the seat of the Peshwa rulers during the Maratha Empire. The palace is renowned for its intricate woodenwork, including the famous Shaniwar Wada fort gate, which is said to be haunted. Visitors can explore the palace's ruins, lush gardens, and the historic Shaniwar Wada fort. The light and sound show held in the evenings narrates the history of the fort and is a popular attraction. Shaniwar Wada offers a glimpse into Pune's rich history and architectural heritage.","Sinhagad Fort, also known as the Lion Fort, is a hill fortress located on the outskirts of Pune. The fort has a storied history and played a significant role in the Maratha Empire. Visitors can trek to the top of the fort, enjoying panoramic views of the surrounding landscape. The fort houses historical structures like the Kondana Cave and Tanaji's memorial. It's a popular destination for nature enthusiasts, history buffs, and trekkers.","The Osho International Meditation Resort, commonly known as the Osho Ashram, is a tranquil oasis in Pune. Founded by the spiritual guru Osho Rajneesh, the ashram is a place for meditation, self-discovery, and relaxation. Visitors can participate in meditation sessions, explore the lush gardens, and engage in various holistic activities. The ashram's serene ambiance and the opportunity for self-reflection make it a unique and peaceful destination in Pune.","The Dagdusheth Halwai Ganpati Temple is one of Pune's most revered temples dedicated to Lord Ganesha. The temple is known for its grandeur and the magnificent idol of Lord Ganesha, adorned with gold and precious jewels. Devotees and visitors flock to the temple to seek blessings and witness the rich cultural and religious traditions. The temple is especially vibrant during the Ganesh Chaturthi festival when the city comes alive with processions and celebrations."]
    
    //Marks : Aurangabad Array Detail
var arrAurangabadPlaceName: [String] = ["Ajanta Caves", "Ellora Caves", "Bibi Ka Maqbara", "Aurangabad Caves", "Daulatabad Fort"]
    var imgAurangabad : [String] = ["ic_AjantaCaves","ic_ElloraCaves","ic_BibiKaMaqbara","ic_AurangabadCaves","ic_DaulatabadFort"]
var arrAurangabadTripDuration: [String] =  ["Half-day to full day", "Half-day to full day", "1-2 hours", "1-2 hours", "Half-day to full day"]
var arrAurangabadBestSeason: [String] = ["October to March", "October to March", "October to March", "October to March", "October to March"]
var arrAurangabadPeakSeason: [String] =  ["November to February", "November to February", "November to February", "November to February", "November to February"]
    var arrAurangabadDetail : [String] = ["The Ajanta Caves are a UNESCO World Heritage Site and a marvel of ancient Indian rock-cut architecture. Located in the Sahyadri hills, these caves date back to the 2nd century BCE and are known for their exquisite Buddhist cave temples and monasteries. The caves feature intricate carvings, sculptures, and breathtaking frescoes that depict the life of Lord Buddha and various Jataka tales. Exploring the Ajanta Caves offers a fascinating journey into India's rich artistic and religious history, making it a must-visit for history enthusiasts and art lovers.","The Ellora Caves, another UNESCO World Heritage Site, are a remarkable complex of rock-cut temples and monasteries spanning Hindu, Buddhist, and Jain traditions. These caves were excavated over a span of several centuries, from the 6th to 10th centuries CE. The site includes 34 caves featuring intricate carvings, stunning sculptures, and grand architectural structures. The most famous cave at Ellora is the Kailash Temple, dedicated to Lord Shiva, which is renowned for its grandeur and size. Visiting Ellora is a journey through time and spirituality, showcasing the diversity of India's religious and cultural heritage.","Bibi Ka Maqbara, often referred to as the Mini Taj Mahal, is a mausoleum located in Aurangabad. Built in the 17th century by Emperor Aurangzeb in memory of his wife, Dilras Banu Begum, the monument bears a striking resemblance to the Taj Mahal in Agra. While smaller in scale, Bibi Ka Maqbara features intricate marble work, delicate lattice screens, and a beautifully landscaped garden. It offers a serene and picturesque setting, making it a popular spot for history enthusiasts and photographers.","The Aurangabad Caves are a group of rock-cut Buddhist caves located on a hill in Aurangabad. These caves, dating back to the 6th and 7th centuries, are notable for their unique architectural styles and Buddhist sculptures. The caves consist of viharas (monasteries) and chaityas (prayer halls) adorned with intricate carvings and sculptures. Exploring the Aurangabad Caves provides insights into the rich Buddhist heritage of the region and offers a peaceful atmosphere for meditation and reflection.","Daulatabad Fort, also known as Devagiri Fort, is a historic hilltop fortress located near Aurangabad. The fort has a storied past, having served as the capital of the Tughlaq dynasty in the 14th century. It features impressive defensive structures, including massive walls, cannons, and a complex series of gates and tunnels. One of the fort's highlights is the Chand Minar, a tall tower built by Sultan Ala-ud-din Bahman Shah. The climb to the top of the fort rewards visitors with panoramic views of the surrounding landscape. Daulatabad Fort is a blend of history, architecture, and natural beauty, making it a fascinating destination for history buffs and adventurers."]
    
    //Marks : Lonavala Array Details
var arrLonavalaPlaceName: [String] = ["Tiger's Leap", "Bhushi Dam", "Karla Caves", "Rajmachi Fort"]
    var imgLonavala : [String] = ["img_Tiger's_Leap","ic_BhushiDam","ic_KarlaCaves","ic_RajmachiFort"]
var arrLonavalaTripDuration: [String] =  ["1-2 hours", "2-3 hours", "1-2 hours", "Half-day to full day"]
var arrLonavalaBestSeason: [String] = ["October to March", "June to September (Monsoon season)", "October to March", "October to March"]
var arrLonavalaPeakSeason: [String] = ["October to March", "June to September (Monsoon season)", "October to March", "October to March"]
    var arrLonavala : [String] = ["Tiger's Leap, also known as Tiger Point, is a scenic viewpoint located in Lonavala. The name is derived from the shape of the rock, which resembles a leaping tiger. This vantage point offers breathtaking views of the surrounding hills and valleys, making it a popular spot for nature enthusiasts and photographers. Visitors can enjoy the serene atmosphere, take in the panoramic vistas, and capture memorable photographs. Tiger's Leap is especially mesmerizing during the monsoon season when the lush green landscape comes alive with cascading waterfalls.","Bhushi Dam is a picturesque dam and recreational area located near Lonavala. It is a favorite destination for visitors looking to relax amidst nature. During the monsoon season, the dam overflows, creating a series of natural waterfalls and inviting pools. Visitors can wade in the refreshing waters, have picnics by the banks, and enjoy the lush surroundings. Bhushi Dam offers a perfect blend of natural beauty and tranquility, making it an ideal spot for a day of relaxation.","The Karla Caves are a complex of ancient Buddhist rock-cut cave temples located near Lonavala. These caves date back to the 2nd century BCE and are renowned for their architectural and sculptural beauty. The main cave, known as the Karla Cave, houses a large stupa (Buddhist shrine) and intricately carved pillars and sculptures. Visitors can explore the cave complex, admire the artistry, and gain insights into Buddhist history and culture. The surroundings provide a serene backdrop for contemplation and reflection.","Rajmachi Fort is a historic hilltop fortress situated in the Western Ghats near Lonavala. It consists of two forts, Shrivardhan Fort and Manaranjan Fort, and offers panoramic views of the Sahyadri mountains and valleys. The trek to Rajmachi Fort is a popular adventure activity for trekkers and nature enthusiasts. The journey takes you through lush forests, picturesque landscapes, and scenic viewpoints. Upon reaching the fort, you can explore its ancient structures, including ramparts, temples, and reservoirs. Rajmachi Fort provides a unique blend of history, adventure, and natural beauty, making it a rewarding destination for trekkers and history buffs alike."]
    
    //Marks : Gujarat Array Detail
var arrGujaratPlaceName: [String] =  ["Gir National Park", "Rann of Kutch", "Somnath Temple", "Sabarmati Ashram", "Dwarkadhish Temple"]
    var imgGujarat : [String] = ["ic_GirNationalPark","ic_RannofKutch","ic_SomnathTemple","ic_SabarmatiAshram","ic_DwarkadhishTemple"]
var arrGujaratTripDuration: [String] = ["2-3 days", "2-3 days", "Half-day to full day", "1-2 hours", "1-2 hours"]
var arrGujaratBestSeason: [String] =  ["December to April", "October to March", "October to March", "October to March", "October to March"]
var arrGujaratPeakSeason: [String] = ["December to April", "October to March", "October to March", "October to March", "October to March"]
    var arrGujrat : [String] = ["Located in the Saurashtra region of Gujarat, it is dedicated to the conservation of this critically endangered species. The park is also home to a diverse range of wildlife, including leopards, hyenas, crocodiles, and various bird species. Visitors can embark on safaris within the park to catch glimpses of these majestic animals in their natural habitat. Gir National Park offers a unique opportunity to witness the magnificent Asiatic lion, making it a must-visit for wildlife enthusiasts and nature lovers.","The Rann of Kutch is a vast salt marsh located in the western part of Gujarat. This unique landscape undergoes a transformation during the monsoon season when it is submerged in water, and during the dry season, it becomes a shimmering white desert. The Rann Utsav, a cultural festival, is a highlight of the region, showcasing Gujarat's rich heritage through music, dance, and traditional crafts. Visitors can explore the desert, witness spectacular sunsets, and engage in activities like camel rides. The Rann of Kutch is a surreal destination that offers a glimpse into the diverse geography and culture of Gujarat.","The Somnath Temple, located in the town of Prabhas Patan, is one of the 12 Jyotirlinga shrines dedicated to Lord Shiva. It is known for its rich history and spiritual significance. The temple has been rebuilt several times throughout history and showcases impressive architecture and intricate carvings. Devotees and tourists visit the temple to seek blessings, witness the aarti (prayer ceremony), and explore the serene temple premises by the Arabian Sea. The Somnath Temple is a symbol of faith and devotion and holds a special place in the hearts of Hindus.","The Sabarmati Ashram, also known as Gandhi Ashram, is located on the banks of the Sabarmati River in Ahmedabad. This ashram served as the residence of Mahatma Gandhi during India's struggle for independence. Today, it stands as a museum and memorial dedicated to the life and teachings of the Father of the Nation, Mahatma Gandhi. Visitors can explore the ashram, view Gandhi's personal belongings, and gain insights into his philosophy of non-violence and civil disobedience. The peaceful surroundings and historic significance make it a place for reflection and inspiration.","The Dwarkadhish Temple, situated in the city of Dwarka, is one of the prominent Hindu temples dedicated to Lord Krishna. It is believed to be the ancient city of Lord Krishna's kingdom, Dwarka, and the temple stands as a symbol of devotion to him. The temple's architectural beauty, with its towering spire and intricate carvings, is a sight to behold. Devotees flock to the temple to offer prayers, witness the daily rituals, and seek blessings. Dwarkadhish Temple is a significant pilgrimage destination for followers of Lord Krishna and a place of spiritual significance."]
    
    //Marks : MadhyaPardesh Array
var arrMadhyaPardeshPlaceName: [String] =  ["Khajuraho Temples", "Sanchi Stupa", "Bandhavgarh National Park", "Kanha National Park", "Gwalior Fort"]
    var imgMadhyaPardesh : [String] = ["ic_KhajurahoTemples","ic_SanchiStupa","ic_Bandhavgarh","ic_KanhaNationalPark","ic_GwaliorFort"]
var arrMadhyaPardeshTripDuration: [String] =  ["1-2 days", "Half-day to full day", "2-3 days", "2-3 days", "Half-day to full day"]
var arrMadhyaPardeshBestSeason: [String] =  ["October to March", "October to March", "November to June", "November to June", "October to March"]
var arrMadhyaPardeshPeakSeason:[String] =   ["November to February", "October to March", "December to April", "December to April", "November to February"]
    var arrMadhyaPardeshDetail : [String] = ["The Khajuraho Temples are a group of stunning and intricately carved Hindu and Jain temples located in Khajuraho, a UNESCO World Heritage Site in Madhya Pradesh. Built between the 9th and 11th centuries, these temples are renowned for their exquisite and highly erotic sculptures that depict various aspects of human life, spirituality, and sensuality. The temples are divided into three groups: Western, Eastern, and Southern, each with its unique architectural and artistic features. Beyond their erotic depictions, the Khajuraho Temples are a testament to the exceptional craftsmanship and architectural brilliance of ancient India. They also serve as a significant pilgrimage site for devotees.","The Sanchi Stupa is a Buddhist monument located in Sanchi, a UNESCO World Heritage Site in Madhya Pradesh. This ancient stupa dates back to the 3rd century BCE and is one of the oldest stone structures in India. It was built by the great Mauryan emperor Ashoka and represents a significant site in Buddhist history. The stupa features a hemispherical dome adorned with intricate carvings and depicts various scenes from the life of Lord Buddha. Visitors can explore the stupa complex, which includes other stupas, monasteries, and pillars. Sanchi Stupa is a peaceful and spiritually significant destination for those interested in Buddhism and ancient Indian history.","Bandhavgarh National Park is a renowned wildlife sanctuary located in the Umaria district of Madhya Pradesh. It is known for its high density of tigers and is one of the best places in India to spot these majestic big cats in the wild. The park also houses a variety of other wildlife species, including leopards, deer, sloth bears, and a rich avian population. Visitors can enjoy thrilling safaris, both jeep and elephant safaris, to explore the park's diverse ecosystems and seek glimpses of its inhabitants. Bandhavgarh National Park is a must-visit destination for wildlife enthusiasts and photographers.","Kanha National Park, also located in Madhya Pradesh, is another prominent wildlife sanctuary known for its thriving tiger population and rich biodiversity. It is one of the largest national parks in India and offers a pristine natural environment with dense forests, meadows, and water bodies. The park is home to a wide range of wildlife, including tigers, leopards, Indian bison (gaur), deer, and various bird species. Visitors can embark on safaris to explore the park's diverse ecosystems and appreciate the beauty of the wilderness. Kanha National Park provides an immersive wildlife experience and is a haven for nature lovers.","Gwalior Fort, situated in the city of Gwalior, is one of the most impressive and historic forts in India. This majestic fort stands atop a rocky hill and has a rich history dating back over a thousand years. It has witnessed the rule of various dynasties, including the Tomars, Mughals, and Marathas. The fort is known for its stunning architecture, intricate carvings, and the iconic Man Singh Palace, which showcases a blend of Rajput and Mughal architectural styles. The Teli Ka Mandir and Saas Bahu Temples within the fort complex are notable for their exquisite craftsmanship. The Gwalior Fort offers panoramic views of the city and is a treasure trove of history and architecture."]
    @IBOutlet var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "CellC_OriginDetail", bundle: nil), forCellWithReuseIdentifier: "CellC_OriginDetail")
    }
}
extension WestTripList : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let selctedIndex = selctedIndex{
            switch selctedIndex{
            case 0:
                return arrGoaplacename.count
            case 1:
                return ArrRajasthanPlaces.count
            case 2:
                return arrMumbaiPlaceName.count
            case 3:
                return arrGujaratPlaceName.count
            case 4:
                return arrMadhyaPardeshPlaceName.count
            default:
                return 0
            }
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let selctedIndex = selctedIndex{
            switch selctedIndex{
            case 0 :
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lblPeakSeason.text = arrGoapeakseason[indexPath.row]
                cell.lblTripDuration.text = arrGoatripduration[indexPath.row]
                cell.lbl_bestTimeToVisit.text = arrGoabestseason[indexPath.row]
                cell.img_Origin.image = UIImage(named: imgGoa[indexPath.row])
                cell.lbl_OriginTittle.text = arrGoaplacename[indexPath.row]
                cell.lbl_stateName.text = "Goa"
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 1:
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lblPeakSeason.text = ArrPeakSeasonRajasthan[indexPath.row]
                cell.lblTripDuration.text = ArrTripDurationsRajasthan[indexPath.row]
                cell.lbl_bestTimeToVisit.text = ArrBestSeasonRajasthan[indexPath.row]
                cell.img_Origin.image = UIImage(named: imgRajasthan[indexPath.row])
                cell.lbl_OriginTittle.text = ArrRajasthanPlaces[indexPath.row]
                cell.lbl_stateName.text = "Rajasthan"
                return cell
            case 2:
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lblPeakSeason.text = arrMubaiPeakSeason[indexPath.row]
                cell.lblTripDuration.text = arrMumbaiTripDuration[indexPath.row]
                cell.lbl_bestTimeToVisit.text = arrMumbaiBestSeason[indexPath.row]
                cell.img_Origin.image = UIImage(named: imgMumbai[indexPath.row])
                cell.lbl_OriginTittle.text = arrMumbaiPlaceName[indexPath.row]
                cell.lbl_stateName.text = "Maharashtra"
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 3:
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lblPeakSeason.text = arrGujaratPeakSeason[indexPath.row]
                cell.lblTripDuration.text = arrGujaratTripDuration[indexPath.row]
                cell.lbl_bestTimeToVisit.text = arrGujaratBestSeason[indexPath.row]
                cell.img_Origin.image = UIImage(named: imgGujarat[indexPath.row])
                cell.lbl_OriginTittle.text = arrGujaratPlaceName[indexPath.row]
                cell.lbl_stateName.text = "Gujarat"
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            case 4:
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath) as! CellC_OriginDetail
                cell.lblPeakSeason.text = arrMadhyaPardeshPeakSeason[indexPath.row]
                cell.lblTripDuration.text = arrMadhyaPardeshTripDuration[indexPath.row]
                cell.lbl_bestTimeToVisit.text = arrMadhyaPardeshBestSeason[indexPath.row]
                cell.img_Origin.image = UIImage(named: imgMadhyaPardesh[indexPath.row])
                cell.lbl_OriginTittle.text = arrMadhyaPardeshPlaceName[indexPath.row]
                cell.lbl_stateName.text = "Madhya Pradesh"
                cell.img_Origin.layer.cornerRadius = 8
                cell.vwMain.layer.cornerRadius = 8
                cell.vwMain.layer.borderWidth = 1
                cell.vwMain.layer.borderColor = UIColor.gray.cgColor
                return cell
            default :
                return UICollectionViewCell()
            }
        }
        return UICollectionViewCell()
        }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AboutDetailVC") as? AboutDetailVC
        if let selectedindex = selctedIndex{
            switch selectedindex{
            case 0 :
                vc?.WestIndia = arrGoaDetail[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            case 1:
                vc?.WestIndia = ArrRajasthanPlaceDetails[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            case 2:
                vc?.WestIndia = arrMumbaiDetail[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            case 3:
                vc?.WestIndia = arrGujaratPlaceName[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            case 4:
                vc?.WestIndia = arrMadhyaPardeshDetail[indexPath.row]
                self.navigationController?.pushViewController(vc!, animated: true)
            default : break
            }
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        if let selectedindex = selctedIndex{
            switch selectedindex{
            case 0:
                return 0
            case 1:
                return 0
            case 2:
                return 0
            case 3:
                return 0
            case 4:
                return 0
            default :
                return 0.0
            }
        }
        return 0.0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        if let selectedindex = selctedIndex{
            switch selectedindex{
            case 0:
                return 0
            case 1:
                return 0
            case 2:
                return 0
            case 3:
                return 0
            case 4:
                return 0
            default :
                return 0.0
            }
        }
        return 0.0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = collectionView.bounds.width
        if let selectedindex = selctedIndex{
            switch selectedindex{
            case 0:
                return CGSize(width: size/1, height: size/1)
            case 1:
                return CGSize(width: size/1, height: size/1)
            case 2:
                return CGSize(width: size/1, height: size/1)
            case 3:
                return CGSize(width: size/1, height: size/1)
            case 4:
                return CGSize(width: size/1, height: size/1)
            default :
                return CGSize.zero
            }
        }
        return CGSize.zero
    }
}
