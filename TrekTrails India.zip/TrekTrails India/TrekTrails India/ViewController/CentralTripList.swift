//
//  CentralTripList.swift
//  TrekTrails India
//
//  Created by syed fazal abbas on 08/09/23.
//

import UIKit

class CentralTripList: UIViewController {

    var selectedIndex : Int?
    var arrMPPlaceName: [String] = [
        "Khajuraho Temples",
        "Sanchi Stupa",
        "Bandhavgarh National Park",
        "Kanha National Park",
        "Gwalior Fort",
        "Pachmarhi",
        "Mandu",
        "Bhedaghat",
        "Chitrakoot",
        "Bhopal",
        "Orchha",
        "Pench National Park"
    ]
    var imgMP : [String] = ["ic_KhajurahoTYemples","ic_SanchiStupa","ic_Bandhavgarh","ic_Kanha","ic_Gwalior","ic_Pachmarhi","ic_Mandu","ic_Bhedaghat","ic_Chitrakoot","ic_Bhopal","ic_Orchha","ic_Pench"]
    
        var arrMPPeakSeason: [String] = [
            "October to March",    // Khajuraho Temples
            "October to March",    // Sanchi Stupa
            "November to June",    // Bandhavgarh National Park
            "November to June",    // Kanha National Park
            "October to March",    // Gwalior Fort
            "September to June",   // Pachmarhi
            "October to March",    // Mandu
            "October to March",    // Bhedaghat
            "October to March",    // Chitrakoot
            "October to March",    // Bhopal
            "October to March",    // Orchha
            "November to June"     // Pench National Park
        ]
        var arrMPBestSeason: [String] = [
            "October to March",    // Khajuraho Temples
            "October to March",    // Sanchi Stupa
            "November to February", // Bandhavgarh National Park
            "November to February", // Kanha National Park
            "October to March",    // Gwalior Fort
            "October to June",     // Pachmarhi
            "October to March",    // Mandu
            "October to March",    // Bhedaghat
            "October to March",    // Chitrakoot
            "October to March",    // Bhopal
            "October to March",    // Orchha
            "November to February"  // Pench National Park
        ]
        var arrMPTripDuration: [String] = [
            "1-2 days",           // Khajuraho Temples
            "Half-day to full day", // Sanchi Stupa
            "2-3 days",            // Bandhavgarh National Park
            "2-3 days",            // Kanha National Park
            "Half-day to full day", // Gwalior Fort
            "2-3 days",            // Pachmarhi
            "1-2 days",           // Mandu
            "Half-day to full day", // Bhedaghat
            "1-2 days",           // Chitrakoot
            "1-2 days",           // Bhopal
            "1-2 days",           // Orchha
            "2-3 days"            // Pench National Park
        ]
    var arrMPDetail : [String] = ["The Khajuraho Temples are a marvel of architecture and artistry. These UNESCO World Heritage Sites, constructed between the 9th and 11th centuries by the Chandela dynasty, showcase a stunning array of intricately carved sculptures that depict a wide range of subjects, from divine deities to intricate human relationships. These temples, with their exceptional craftsmanship and erotic art, offer a unique glimpse into ancient India's cultural and artistic traditions.","Sanchi Stupa is a living testament to India's Buddhist heritage. Emperor Ashoka commissioned the construction of this sacred site in the 3rd century BCE. The Great Stupa at Sanchi stands as a symbol of peace and spirituality, adorned with the world's oldest stone carvings depicting the life of Buddha. The intricate toranas (gateways) surrounding the stupa provide insight into the rich Buddhist history and artistry.","Known as the Land of the Tigers, Bandhavgarh National Park is a sanctuary for India's majestic big cats. The park's lush forests and hilly terrain provide a pristine habitat for a thriving population of tigers, making it one of the best places for tiger sightings in the country. Beyond tigers, Bandhavgarh is home to diverse wildlife, including leopards, deer, langurs, and a multitude of bird species. The park's rugged beauty and lush landscapes offer an unforgettable experience for wildlife enthusiasts and photographers.","Kanha National Park is another gem in Madhya Pradesh's wildlife crown. The park's expansive grasslands, dense forests, and meandering rivers create a mesmerizing landscape that serves as a refuge for a wide variety of wildlife. Tigers, leopards, sloth bears, and the elusive barasingha deer call Kanha home. The park's picturesque surroundings and abundant flora and fauna make it a prime destination for nature lovers and wildlife photographers.","Gwalior Fort is a magnificent structure that has stood the test of time, bearing witness to centuries of history. This imposing fort showcases a blend of Rajput and Mughal architectural styles, with grand gates, palaces, temples, and intricately designed structures. The Man Mandir Palace within the fort features exquisite blue-tiled mosaics. Gwalior Fort also boasts panoramic views of the city and the surrounding landscape, offering a glimpse into the opulence and valor of the past."," Pachmarhi, often referred to as the Queen of Satpura, is a hill station nestled in the Satpura Range. This charming town is surrounded by dense forests, cascading waterfalls, and serene viewpoints. It's an ideal destination for nature lovers, offering opportunities for hiking, exploring caves, and enjoying the tranquility of Apsara Vihar waterfall.","Mandu is a historical treasure trove, known for its magnificent palaces, mosques, and step wells. It was once a thriving medieval city and is now an archaeological delight. The architectural wonders of Mandu, including the Jahaz Mahal (Ship Palace) and Hoshang Shah's Tomb, narrate tales of love and valor from bygone eras.","Bhedaghat is famous for its stunning marble rocks, which rise dramatically along the Narmada River. The Dhuandhar Falls, where the river plunges through these marble rocks, is a mesmerizing sight. Visitors can take boat rides on the Narmada to witness the marble canyon and the natural beauty of the area.","Chitrakoot is a spiritual and cultural hub associated with Lord Rama's exile. It is believed to be a place where Lord Rama, along with Sita and Lakshmana, spent some of their years in exile. The town is dotted with temples, ghats along the Mandakini River, and natural beauty. It's a place of pilgrimage and reflection.","Bhopal, the capital of Madhya Pradesh, is a vibrant city known for its cultural heritage and modern amenities. The city offers a blend of historical sites, such as the UNESCO-listed Bhimbetka Caves with ancient rock paintings, and contemporary attractions like museums and bustling markets. Bhopal also boasts a rich culinary scene, with flavors ranging from traditional Indian cuisine to international delicacies.","Orchha is a hidden gem steeped in history and charm. The town is famous for its grand palaces, temples, and cenotaphs that stand as a testament to its royal past. The serene Betwa River adds to the town's allure, making it a tranquil destination for those seeking a glimpse into India's regal heritage.","Pench National Park, located in the southern reaches of Madhya Pradesh, is a wilderness paradise. It is known for its diverse flora and fauna, with a wide variety of wildlife species, including tigers, leopards, and an abundance of birdlife. The park's landscapes, encompassing teak forests, open grasslands, and meandering rivers, provide a picturesque backdrop for safaris and wildlife encounters."]
    
    @IBOutlet var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(UINib(nibName: "CellC_OriginDetail", bundle: nil), forCellWithReuseIdentifier: "CellC_OriginDetail")
    }
}
extension CentralTripList : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrMPPlaceName.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellC_OriginDetail", for: indexPath)
        as! CellC_OriginDetail
        cell.lbl_stateName.text = "Madhya Pradesh"
        cell.lblPeakSeason.text = arrMPPeakSeason[indexPath.row]
        cell.lbl_OriginTittle.text = arrMPPlaceName[indexPath.row]
        cell.lblTripDuration.text = arrMPTripDuration[indexPath.row]
        cell.lbl_bestTimeToVisit.text = arrMPBestSeason[indexPath.row]
        cell.img_Origin.image = UIImage(named: imgMP[indexPath.row])
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AboutDetailVC") as? AboutDetailVC
        vc?.CentralIndia = arrMPDetail[indexPath.row]
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
       return 0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = collectionView.bounds.width
        return CGSize(width: size/1, height: size/1)
    }
}

