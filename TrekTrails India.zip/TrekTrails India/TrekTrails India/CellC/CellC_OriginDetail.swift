//
//  CellC_OriginDetail.swift
//  TrekTrails India
//
//  Created by syed fazal abbas on 04/09/23.
//

import UIKit

class CellC_OriginDetail: UICollectionViewCell {

    @IBOutlet var lbl_OriginTittle: UILabel!
    @IBOutlet var vwMain: UIView!
    @IBOutlet var vwDetail: UIView!
    @IBOutlet var img_Origin: UIImageView!
    @IBOutlet var lbl_stateName: UILabel!
    @IBOutlet var lbl_bestTimeToVisit: UILabel!
    @IBOutlet var lblPeakSeason: UILabel!
    @IBOutlet var lblTripDuration: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
