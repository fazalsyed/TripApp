//
//  CellC_Destination.swift
//  TrekTrails India
//
//  Created by syed fazal abbas on 04/09/23.
//

import UIKit

class CellC_Destination: UICollectionViewCell {

    @IBOutlet var img_Destination: UIImageView!
    @IBOutlet var lbl_Destination: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
